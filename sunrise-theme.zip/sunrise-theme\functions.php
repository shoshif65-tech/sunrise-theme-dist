<?php
/**
 * Sunrise theme setup.
 */

require get_template_directory() . '/admin-dashboard.php';

// Where contact-form submissions get emailed.
add_filter( 'sunrise_contact_notify_email', function () {
	return 'shoshif65@gmail.com';
} );

add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
} );

add_action( 'wp_enqueue_scripts', function () {
	$dir = get_template_directory();
	$uri = get_template_directory_uri();

	// Printed inline (not as a linked file) so the page's real styling is
	// present from the very first paint — exactly like the original
	// single-file page, and with nothing for the browser to flash
	// unstyled content while it waits on a separate CSS request.
	wp_register_style( 'sunrise-style', false );
	wp_enqueue_style( 'sunrise-style' );
	wp_add_inline_style( 'sunrise-style', file_get_contents( $dir . '/style.css' ) );

	wp_enqueue_script( 'sunrise-main', $uri . '/js/main.js', [], filemtime( $dir . '/js/main.js' ), true );
	wp_localize_script( 'sunrise-main', 'sunriseTheme', [
		'imagesUrl' => $uri . '/images',
		'restUrl'   => esc_url_raw( rest_url() ),
	] );
}, 20 );

/**
 * The install has Elementor/JetEngine/JetPopup/JetSearch active (for
 * possible future use), but this page is 100% hand-coded and uses none of
 * their widgets — their frontend CSS/JS was loading on every visit for
 * nothing: extra requests and extra script-parsing time fighting our own
 * code for the browser's attention. Strip anything from those plugins
 * (and the hello-elementor base theme, which we don't use either) off
 * the front end specifically; wp-admin is untouched.
 */
add_action( 'wp_enqueue_scripts', function () {
	$skip_if_src_matches = '#/(elementor|jet-engine|jet-popup|jet-search|jet-elements|jet-smart-filters|hello-elementor)/#';

	foreach ( wp_styles()->queue as $handle ) {
		$src = wp_styles()->registered[ $handle ]->src ?? '';
		if ( $src && preg_match( $skip_if_src_matches, $src ) ) {
			wp_dequeue_style( $handle );
		}
	}
	foreach ( wp_scripts()->queue as $handle ) {
		$src = wp_scripts()->registered[ $handle ]->src ?? '';
		if ( $src && preg_match( $skip_if_src_matches, $src ) ) {
			wp_dequeue_script( $handle );
		}
	}
}, 9999 );

/**
 * "Project" custom post type — the content clients edit themselves from
 * wp-admin to add/remove/reorder cards in the Projects section. Order is
 * controlled with the native page-attributes "Order" field (menu_order);
 * the card's "01/02/..." number is generated automatically from its
 * position, not stored per-post, so there's nothing to keep in sync.
 */
add_action( 'init', function () {
	register_post_type( 'project', [
		'labels' => [
			'name'               => 'פרויקטים',
			'singular_name'      => 'פרויקט',
			'add_new'            => 'הוספת פרויקט',
			'add_new_item'       => 'הוספת פרויקט חדש',
			'edit_item'          => 'עריכת פרויקט',
			'new_item'           => 'פרויקט חדש',
			'view_item'          => 'צפייה בפרויקט',
			'search_items'       => 'חיפוש פרויקטים',
			'not_found'          => 'לא נמצאו פרויקטים',
			'not_found_in_trash' => 'לא נמצאו פרויקטים באשפה',
			'menu_name'          => 'פרויקטים',
		],
		'public'          => true,
		'has_archive'     => false,
		'show_in_menu'    => true,
		'menu_icon'       => 'dashicons-building',
		'supports'        => [ 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes' ],
		'rewrite'         => [ 'slug' => 'project' ],
		'show_in_rest'    => true,
		'rest_base'       => 'projects',
		'capability_type' => 'project',
		'map_meta_cap'    => true,
		'capabilities'    => [
			'edit_post'          => 'edit_project',
			'edit_posts'         => 'edit_projects',
			'edit_others_posts'  => 'edit_others_projects',
			'edit_private_posts' => 'edit_private_projects',
			'edit_published_posts' => 'edit_published_projects',
			'publish_posts'      => 'publish_projects',
			'read_post'          => 'read_project',
			'read_private_posts' => 'read_private_projects',
			'delete_post'        => 'delete_project',
			'delete_posts'       => 'delete_projects',
			'delete_others_posts' => 'delete_others_projects',
			'delete_private_posts' => 'delete_private_projects',
			'delete_published_posts' => 'delete_published_projects',
		],
	] );

	/**
	 * Contact-form submissions. Not public (no front-end URL of its own) —
	 * admins read them from wp-admin; the client's own dashboard doesn't
	 * show this post type at all.
	 */
	register_post_type( 'contact_message', [
		'labels' => [
			'name'          => 'פניות מהאתר',
			'singular_name' => 'פנייה',
			'menu_name'     => 'פניות מהאתר',
		],
		'public'       => false,
		'show_ui'      => true,
		'show_in_menu' => true,
		'menu_icon'    => 'dashicons-email',
		'supports'     => [ 'title' ],
		'capability_type' => 'page', // administrators only — no client role grants these caps
	] );
} );

/**
 * Public REST endpoint the contact form submits to. No auth required (the
 * visitor isn't logged in) — protected instead by a honeypot field and
 * server-side sanitizing; it only ever creates a private contact_message
 * post, nothing it touches is public or destructive.
 */
add_action( 'rest_api_init', function () {
	register_rest_route( 'sunrise/v1', '/contact', [
		'methods'             => 'POST',
		'permission_callback' => '__return_true',
		'callback'            => function ( WP_REST_Request $req ) {
			$name    = sanitize_text_field( $req->get_param( 'name' ) );
			$phone   = sanitize_text_field( $req->get_param( 'phone' ) );
			$email   = sanitize_email( $req->get_param( 'email' ) );
			$message = sanitize_textarea_field( $req->get_param( 'message' ) );
			$website = $req->get_param( 'website' ); // honeypot — real visitors never fill this

			if ( ! empty( $website ) ) {
				// Looks like a bot — report success without doing anything.
				return new WP_REST_Response( [ 'success' => true ], 200 );
			}

			if ( empty( $name ) || empty( $phone ) || ! is_email( $email ) ) {
				return new WP_REST_Response( [
					'success' => false,
					'message' => 'נא למלא שם, טלפון ואימייל תקין.',
				], 400 );
			}

			$post_id = wp_insert_post( [
				'post_type'   => 'contact_message',
				'post_title'  => sprintf( '%s — %s', $name, $phone ),
				'post_status' => 'publish',
				'meta_input'  => [
					'contact_phone'   => $phone,
					'contact_email'   => $email,
					'contact_message' => $message,
				],
			], true );

			if ( is_wp_error( $post_id ) ) {
				return new WP_REST_Response( [
					'success' => false,
					'message' => 'שגיאה בשמירת הפנייה.',
				], 500 );
			}

			$to = apply_filters( 'sunrise_contact_notify_email', get_option( 'admin_email' ) );
			wp_mail(
				$to,
				'פנייה חדשה מהאתר — ' . $name,
				"שם: {$name}\nטלפון: {$phone}\nאימייל: {$email}\n\nהודעה:\n{$message}"
			);

			return new WP_REST_Response( [ 'success' => true ], 200 );
		},
	] );
} );
