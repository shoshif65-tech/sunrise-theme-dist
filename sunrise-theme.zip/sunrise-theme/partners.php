<?php
/**
 * Partner logos ("שיתופי פעולה") — one "partner" post per logo: the title
 * is the company name (also the image's alt text), the featured image is
 * the logo, and menu_order is its place in the strip. Managed from the
 * dashboard's "שיתופי פעולה" tab; the front-page strip reads them in order.
 */

add_action( 'init', function () {
	register_post_type( 'partner', [
		'labels' => [
			'name'          => 'לוגואים - שיתופי פעולה',
			'singular_name' => 'לוגו',
			'menu_name'     => 'לוגואים',
		],
		'public'              => false,
		'publicly_queryable'  => false,
		'exclude_from_search' => true,
		'show_ui'             => true,
		'show_in_menu'        => true,
		'menu_icon'           => 'dashicons-groups',
		'supports'            => [ 'title', 'thumbnail', 'page-attributes', 'custom-fields' ],
		'show_in_rest'        => true,
		'rest_base'           => 'partners',
		'capability_type'     => 'partner',
		'map_meta_cap'        => true,
		'capabilities'        => [
			'edit_post'              => 'edit_partner',
			'edit_posts'             => 'edit_partners',
			'edit_others_posts'      => 'edit_others_partners',
			'edit_private_posts'     => 'edit_private_partners',
			'edit_published_posts'   => 'edit_published_partners',
			'publish_posts'          => 'publish_partners',
			'read_post'              => 'read_partner',
			'read_private_posts'     => 'read_private_partners',
			'delete_post'            => 'delete_partner',
			'delete_posts'           => 'delete_partners',
			'delete_others_posts'    => 'delete_others_partners',
			'delete_private_posts'   => 'delete_private_partners',
			'delete_published_posts' => 'delete_published_partners',
		],
	] );

	// Render the logo as a white silhouette on the dark band (default on).
	register_post_meta( 'partner', 'sunrise_logo_white', [
		'type'          => 'boolean',
		'single'        => true,
		'default'       => true,
		'show_in_rest'  => true,
		'auth_callback' => function () {
			return current_user_can( 'edit_partners' );
		},
	] );
} );

/** Is this logo shown as a white silhouette? (missing meta = yes) */
function sunrise_partner_is_white( $post_id ) {
	if ( ! metadata_exists( 'post', $post_id, 'sunrise_logo_white' ) ) {
		return true;
	}
	return (bool) get_post_meta( $post_id, 'sunrise_logo_white', true );
}

/**
 * Deleting a partner also deletes its logo file, so nothing orphans in the
 * media library - but only a file that is really that logo's own: not one
 * another post still shows, and not one somebody else uploaded. (A partner
 * can be pointed at ANY image id, so without these checks deleting a logo
 * could delete a project photo or an administrator's file.)
 */
add_action( 'before_delete_post', function ( $post_id ) {
	if ( get_post_type( $post_id ) !== 'partner' ) {
		return;
	}
	$thumb_id = (int) get_post_thumbnail_id( $post_id );
	if ( ! $thumb_id ) {
		return;
	}
	$att = get_post( $thumb_id );
	if ( ! $att || $att->post_type !== 'attachment' ) {
		return;
	}
	$others = get_posts( [
		'post_type'   => array_values( get_post_types() ),
		'post_status' => 'any',
		'meta_key'    => '_thumbnail_id',
		'meta_value'  => $thumb_id,
		'exclude'     => [ $post_id ],
		'fields'      => 'ids',
		'numberposts' => 1,
	] );
	if ( $others ) {
		return;
	}
	$author = (int) $att->post_author;
	if ( $author !== get_current_user_id() && $author !== 0 && ! current_user_can( 'manage_options' ) ) {
		return;
	}
	wp_delete_attachment( $thumb_id, true );
} );

/**
 * One-time seed: turn the three logos that used to be hardcoded in the
 * template into real partner posts, so the strip looks the same on the
 * first load after this ships and the client edits real entries from the
 * start. add_option() is the lock — it only succeeds once, so concurrent
 * first requests can't seed twice.
 */
add_action( 'init', function () {
	if ( get_option( 'sunrise_partners_seeded' ) ) {
		return;
	}
	if ( ! add_option( 'sunrise_partners_seeded', '1', '', 'no' ) ) {
		return;
	}
	$counts = wp_count_posts( 'partner' );
	if ( ! empty( $counts->publish ) ) {
		return;
	}

	require_once ABSPATH . 'wp-admin/includes/file.php';
	require_once ABSPATH . 'wp-admin/includes/image.php';
	require_once ABSPATH . 'wp-admin/includes/media.php';

	$seed = [
		[ 'partner-weissgroup.png', 'Weiss Group' ],
		[ 'partner-sufrin.png', 'Sufrin' ],
		[ 'partner-taman.png', 'טעמן נדל"ן' ],
	];
	$dir = get_template_directory() . '/images/';

	foreach ( $seed as $i => $row ) {
		$path = $dir . $row[0];
		if ( ! file_exists( $path ) ) {
			continue;
		}
		$upload = wp_upload_bits( $row[0], null, file_get_contents( $path ) );
		if ( ! empty( $upload['error'] ) ) {
			continue;
		}
		$type = wp_check_filetype( $upload['file'] );
		$att  = wp_insert_attachment( [
			'post_mime_type' => $type['type'],
			'post_title'     => $row[1],
			'post_status'    => 'inherit',
			'post_author'    => 0, // whoever's visit triggered the seed: no owner, so the client may delete these
		], $upload['file'] );
		if ( ! $att || is_wp_error( $att ) ) {
			continue;
		}
		wp_update_attachment_metadata( $att, wp_generate_attachment_metadata( $att, $upload['file'] ) );

		$pid = wp_insert_post( [
			'post_type'   => 'partner',
			'post_title'  => $row[1],
			'post_status' => 'publish',
			'menu_order'  => $i,
		] );
		if ( $pid && ! is_wp_error( $pid ) ) {
			set_post_thumbnail( $pid, $att );
			update_post_meta( $pid, 'sunrise_logo_white', 1 );
		}
	}
}, 30 );
