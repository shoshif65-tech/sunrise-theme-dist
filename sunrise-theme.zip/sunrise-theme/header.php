<!DOCTYPE html>
<html lang="he" dir="rtl">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
  <div class="page">
    <header class="header">
      <div class="logo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" style="display:block"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/logo-sunrise.png" alt="Sunrise"></a></div>
      <ul class="nav-links">
        <?php // Full URLs (not bare #anchors) so the menu also works from inner pages like "all projects". ?>
        <li><a href="<?php echo esc_url( home_url( '/#hero' ) ); ?>">דף הבית</a></li>
        <li><a href="<?php echo esc_url( home_url( '/#about' ) ); ?>">אודות</a></li>
        <li><a href="<?php echo esc_url( home_url( '/#projects' ) ); ?>">פרויקטים</a></li>
        <li><a href="<?php echo esc_url( home_url( '/#partners' ) ); ?>">שת״פ</a></li>
        <li><a href="<?php echo esc_url( home_url( '/#contact' ) ); ?>">צור קשר</a></li>
      </ul>
      <button class="pill-btn nav-cta">
        <?php sunrise_content_html( 'cta_text' ); ?>
        <svg width="24" height="10" viewBox="0 0 24 10" fill="none"><path d="M23 5H1M1 5L4 2.5M1 5L4 7.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" vector-effect="non-scaling-stroke"/></svg>
      </button>
    </header>
