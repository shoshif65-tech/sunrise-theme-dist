<?php
/**
 * A dedicated, fully custom-branded screen for the client — "ניהול פרויקטים".
 * It lives inside wp-admin (reusing WordPress's own login/session security)
 * but is styled entirely on its own, and the client's role never sees the
 * regular WordPress admin screens at all.
 */

define( 'SUNRISE_CLIENT_ROLE', 'sunrise_client' );

/**
 * (Re)create the client role on every load with exactly these capabilities —
 * simplest way to keep them in sync while this is still being built out.
 * Scope: just enough to manage the "project" post type and upload images.
 */
add_action( 'init', function () {
	remove_role( SUNRISE_CLIENT_ROLE );
	add_role( SUNRISE_CLIENT_ROLE, 'לקוח (ניהול אתר)', [
		'read'                    => true,
		'upload_files'            => true,
		'edit_projects'           => true,
		'edit_others_projects'    => true,
		'edit_private_projects'   => true,
		'edit_published_projects' => true,
		'publish_projects'        => true,
		'read_private_projects'   => true,
		'delete_projects'         => true,
		'delete_others_projects'  => true,
		'delete_private_projects' => true,
		'delete_published_projects' => true,
	] );
} );

function sunrise_is_client_user() {
	$user = wp_get_current_user();
	return in_array( SUNRISE_CLIENT_ROLE, (array) $user->roles, true );
}

/** Hide every default admin menu item for the client role — only our page remains. */
add_action( 'admin_menu', function () {
	if ( ! sunrise_is_client_user() ) {
		return;
	}
	global $menu, $submenu;
	remove_menu_page( 'index.php' );
	remove_menu_page( 'edit.php' );
	remove_menu_page( 'upload.php' );
	remove_menu_page( 'edit.php?post_type=page' );
	remove_menu_page( 'edit-comments.php' );
	remove_menu_page( 'themes.php' );
	remove_menu_page( 'plugins.php' );
	remove_menu_page( 'users.php' );
	remove_menu_page( 'tools.php' );
	remove_menu_page( 'options-general.php' );
	remove_menu_page( 'edit.php?post_type=project' );
	remove_menu_page( 'edit.php?post_type=contact_message' );
	// Anything a plugin (Elementor/JetEngine/etc.) added that we didn't
	// explicitly ask for — strip it down to just our own page.
	if ( is_array( $menu ) ) {
		foreach ( $menu as $item ) {
			$slug = $item[2] ?? '';
			if ( $slug && $slug !== 'sunrise-dashboard' ) {
				remove_menu_page( $slug );
			}
		}
	}
}, 999 );

/** No admin bar, no default wp-admin chrome — straight to the dashboard. */
add_action( 'init', function () {
	if ( sunrise_is_client_user() ) {
		add_filter( 'show_admin_bar', '__return_false' );
	}
} );

add_action( 'admin_init', function () {
	if ( ! sunrise_is_client_user() ) {
		return;
	}
	global $pagenow;
	// Land on the dashboard no matter what wp-admin URL they hit.
	if ( $pagenow === 'index.php' || ( $pagenow === 'admin.php' && ( $_GET['page'] ?? '' ) === '' ) ) {
		wp_safe_redirect( admin_url( 'admin.php?page=sunrise-dashboard' ) );
		exit;
	}
} );

add_filter( 'login_redirect', function ( $redirect_to, $requested, $user ) {
	if ( $user instanceof WP_User && in_array( SUNRISE_CLIENT_ROLE, (array) $user->roles, true ) ) {
		return admin_url( 'admin.php?page=sunrise-dashboard' );
	}
	return $redirect_to;
}, 10, 3 );

add_action( 'admin_menu', function () {
	add_menu_page(
		'ניהול פרויקטים',
		'ניהול פרויקטים',
		'read',
		'sunrise-dashboard',
		'sunrise_render_dashboard',
		'dashicons-admin-home',
		2
	);
} );

add_action( 'admin_enqueue_scripts', function ( $hook ) {
	if ( $hook !== 'toplevel_page_sunrise-dashboard' ) {
		return;
	}
	$dir = get_template_directory();
	$uri = get_template_directory_uri();

	wp_enqueue_style( 'sunrise-dashboard', $uri . '/admin/dashboard.css', [], filemtime( $dir . '/admin/dashboard.css' ) );
	wp_enqueue_script( 'sunrise-dashboard', $uri . '/admin/dashboard.js', [], filemtime( $dir . '/admin/dashboard.js' ), true );
	wp_localize_script( 'sunrise-dashboard', 'sunriseDash', [
		'restUrl'   => esc_url_raw( rest_url( 'wp/v2/' ) ),
		'nonce'     => wp_create_nonce( 'wp_rest' ),
		'imagesUrl' => $uri . '/images',
		'logoutUrl' => wp_logout_url( home_url( '/' ) ),
	] );

	// Hide the regular wp-admin chrome entirely for the client role, so this
	// reads as its own branded app rather than "a page inside WordPress".
	if ( sunrise_is_client_user() ) {
		wp_add_inline_style( 'sunrise-dashboard', '
			#adminmenumain, #adminmenuback, #adminmenuwrap, #wpadminbar, #wpfooter, #screen-meta-links { display: none !important; }
			html.wp-toolbar { padding-top: 0 !important; }
			#wpcontent, #wpbody-content { margin-right: 0 !important; padding: 0 !important; }
			#wpbody { padding-top: 0 !important; }
		' );
	}
} );

function sunrise_render_dashboard() {
	?>
	<div id="sunrise-dashboard-root">טוען…</div>
	<?php
}
