<?php
/**
 * Sunrise theme setup.
 */

require get_template_directory() . '/admin-dashboard.php';
require get_template_directory() . '/content-settings.php';
require get_template_directory() . '/partners.php';

// Where contact-form submissions get emailed.
add_filter( 'sunrise_contact_notify_email', function () {
	return 'shoshif65@gmail.com';
} );

/**
 * Permalink structure (e.g. the "project" CPT's archive slug) is cached in
 * the database and only re-read on an explicit flush — bump this whenever
 * such a setting changes, so the live site picks it up automatically on
 * the next load instead of needing a manual trip to Settings > Permalinks.
 */
add_action( 'init', function () {
	$v = '2';
	if ( get_option( 'sunrise_rewrite_v' ) !== $v ) {
		flush_rewrite_rules();
		update_option( 'sunrise_rewrite_v', $v );
	}
}, 20 );

add_action( 'after_setup_theme', function () {
	add_theme_support( 'title-tag' );
	add_theme_support( 'post-thumbnails' );
} );

add_action( 'wp_enqueue_scripts', function () {
	$dir = get_template_directory();
	$uri = get_template_directory_uri();

	// Printed inline (not as a linked file) so the page's real styling is
	// present from the very first paint — exactly like the original
	// single-file page, and with nothing for the browser to flash
	// unstyled content while it waits on a separate CSS request.
	// The stylesheet's own url('fonts/...') is relative to where the CSS
	// file itself used to live; now that it's inlined into the page, a
	// relative path would resolve against the PAGE's url instead — so it's
	// rewritten to an absolute theme url before being printed.
	$css = file_get_contents( $dir . '/style.css' );
	$css = str_replace( "url('fonts/", "url('" . $uri . "/fonts/", $css );

	wp_register_style( 'sunrise-style', false );
	wp_enqueue_style( 'sunrise-style' );
	wp_add_inline_style( 'sunrise-style', $css );

	wp_enqueue_script( 'sunrise-main', $uri . '/js/main.js', [], filemtime( $dir . '/js/main.js' ), true );
	wp_localize_script( 'sunrise-main', 'sunriseTheme', [
		'imagesUrl' => $uri . '/images',
		'restUrl'   => esc_url_raw( rest_url() ),
	] );
}, 20 );

/**
 * Keep main.js out of the host's "Vangus Cache" minify/combine step. That
 * plugin is a WP Rocket build (its /wp-content/cache/min/ layout and wpr_
 * query params), and it was serving a minified copy of main.js that stayed
 * STALE across theme updates — the page kept pointing at an old cached
 * build (verified: the served min copy had none of the current code while
 * the raw file on disk did), so JS changes never reached visitors. The
 * raw file is loaded straight from the theme with its filemtime ?ver=
 * buster, which is the mechanism that's supposed to make updates land.
 */
add_filter( 'script_loader_tag', function ( $tag, $handle ) {
	if ( $handle === 'sunrise-main' ) {
		$tag = str_replace( '<script ', '<script data-no-minify="1" ', $tag );
	}
	return $tag;
}, 10, 2 );
add_filter( 'rocket_exclude_js', function ( $excluded ) {
	$excluded[] = '/wp-content/themes/sunrise-theme/js/main.js';
	return $excluded;
} );
add_filter( 'rocket_exclude_defer_js', function ( $excluded ) {
	$excluded[] = '/wp-content/themes/sunrise-theme/js/main.js';
	return $excluded;
} );

/**
 * The install has Elementor/JetEngine/JetPopup/JetSearch active (for
 * possible future use), but this page is 100% hand-coded and uses none of
 * their widgets — their frontend CSS/JS was loading on every visit for
 * nothing: extra requests and extra script-parsing time fighting our own
 * code for the browser's attention. Strip anything from those plugins
 * (and the hello-elementor base theme, which we don't use either) off
 * the front end specifically; wp-admin is untouched.
 */
add_action( 'wp_enqueue_scripts', function () {
	$skip_if_src_matches = '#/(elementor|jet-engine|jet-popup|jet-search|jet-elements|jet-smart-filters|hello-elementor)/#';

	foreach ( wp_styles()->queue as $handle ) {
		$src = wp_styles()->registered[ $handle ]->src ?? '';
		if ( $src && preg_match( $skip_if_src_matches, $src ) ) {
			wp_dequeue_style( $handle );
		}
	}
	foreach ( wp_scripts()->queue as $handle ) {
		$src = wp_scripts()->registered[ $handle ]->src ?? '';
		if ( $src && preg_match( $skip_if_src_matches, $src ) ) {
			wp_dequeue_script( $handle );
		}
	}
}, 9999 );

/**
 * "Project" custom post type — the content clients edit themselves from
 * wp-admin to add/remove/reorder cards in the Projects section. Order is
 * controlled with the native page-attributes "Order" field (menu_order);
 * the card's "01/02/..." number is generated automatically from its
 * position, not stored per-post, so there's nothing to keep in sync.
 */
add_action( 'init', function () {
	register_post_type( 'project', [
		'labels' => [
			'name'               => 'פרויקטים',
			'singular_name'      => 'פרויקט',
			'add_new'            => 'הוספת פרויקט',
			'add_new_item'       => 'הוספת פרויקט חדש',
			'edit_item'          => 'עריכת פרויקט',
			'new_item'           => 'פרויקט חדש',
			'view_item'          => 'צפייה בפרויקט',
			'search_items'       => 'חיפוש פרויקטים',
			'not_found'          => 'לא נמצאו פרויקטים',
			'not_found_in_trash' => 'לא נמצאו פרויקטים באשפה',
			'menu_name'          => 'פרויקטים',
		],
		'public'          => true,
		'has_archive'     => 'projects',
		'show_in_menu'    => true,
		'menu_icon'       => 'dashicons-building',
		'supports'        => [ 'title', 'editor', 'excerpt', 'thumbnail', 'page-attributes' ],
		'rewrite'         => [ 'slug' => 'project' ],
		'show_in_rest'    => true,
		'rest_base'       => 'projects',
		'capability_type' => 'project',
		'map_meta_cap'    => true,
		'capabilities'    => [
			'edit_post'          => 'edit_project',
			'edit_posts'         => 'edit_projects',
			'edit_others_posts'  => 'edit_others_projects',
			'edit_private_posts' => 'edit_private_projects',
			'edit_published_posts' => 'edit_published_projects',
			'publish_posts'      => 'publish_projects',
			'read_post'          => 'read_project',
			'read_private_posts' => 'read_private_projects',
			'delete_post'        => 'delete_project',
			'delete_posts'       => 'delete_projects',
			'delete_others_posts' => 'delete_others_projects',
			'delete_private_posts' => 'delete_private_projects',
			'delete_published_posts' => 'delete_published_projects',
		],
	] );

	/**
	 * Contact-form submissions. Not public (no front-end URL of its own) —
	 * admins read them from wp-admin; the client's own dashboard doesn't
	 * show this post type at all.
	 */
	register_post_type( 'contact_message', [
		'labels' => [
			'name'          => 'פניות מהאתר',
			'singular_name' => 'פנייה',
			'menu_name'     => 'פניות מהאתר',
		],
		'public'       => false,
		'show_ui'      => true,
		'show_in_menu' => true,
		'menu_icon'    => 'dashicons-email',
		'supports'     => [ 'title' ],
		'capability_type' => 'page', // administrators only — no client role grants these caps
	] );
} );

/**
 * Best-effort visitor address, for rate limiting only. Behind the host's
 * proxy/CDN REMOTE_ADDR can be the proxy itself, so the usual forwarding
 * headers come first. They can be forged, which is why a global cap sits
 * behind the per-address one (see the endpoint below).
 */
function sunrise_client_ip() {
	foreach ( [ 'HTTP_CF_CONNECTING_IP', 'HTTP_X_REAL_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR' ] as $key ) {
		if ( empty( $_SERVER[ $key ] ) ) {
			continue;
		}
		$ip = trim( explode( ',', wp_unslash( $_SERVER[ $key ] ) )[0] );
		if ( filter_var( $ip, FILTER_VALIDATE_IP ) ) {
			return $ip;
		}
	}
	return '';
}

/**
 * Count one use against a named bucket; true while it is still under $max
 * within $window seconds. Transient-backed, so no table of its own.
 */
function sunrise_rate_ok( $bucket, $max, $window ) {
	$key  = 'sunrise_rl_' . md5( $bucket );
	$data = get_transient( $key );
	if ( ! is_array( $data ) || empty( $data['t'] ) || $data['t'] + $window < time() ) {
		$data = [ 'n' => 0, 't' => time() ];
	}
	if ( $data['n'] >= $max ) {
		return false;
	}
	$data['n']++;
	set_transient( $key, $data, max( 1, $data['t'] + $window - time() ) );
	return true;
}

/**
 * Public REST endpoint the contact form submits to. No auth required (the
 * visitor isn't logged in) — protected instead by a honeypot field, size
 * limits, a per-address and a global rate limit, and server-side
 * sanitizing; it only ever creates a private contact_message post, nothing
 * it touches is public or destructive.
 */
add_action( 'rest_api_init', function () {
	register_rest_route( 'sunrise/v1', '/contact', [
		'methods'             => 'POST',
		'permission_callback' => '__return_true',
		'callback'            => function ( WP_REST_Request $req ) {
			$fail = function ( $text, $status = 400 ) {
				return new WP_REST_Response( [ 'success' => false, 'message' => $text ], $status );
			};

			$website = $req->get_param( 'website' ); // honeypot — real visitors never fill this
			if ( ! empty( $website ) ) {
				// Looks like a bot — report success without doing anything.
				return new WP_REST_Response( [ 'success' => true ], 200 );
			}

			$name    = sanitize_text_field( $req->get_param( 'name' ) );
			$phone   = sanitize_text_field( $req->get_param( 'phone' ) );
			$email   = sanitize_email( $req->get_param( 'email' ) );
			$message = sanitize_textarea_field( $req->get_param( 'message' ) );

			if ( empty( $name ) || empty( $phone ) || ! is_email( $email ) ) {
				return $fail( 'נא למלא שם, טלפון ואימייל תקין.' );
			}
			if ( mb_strlen( $name ) > 100 || mb_strlen( $phone ) > 30 || mb_strlen( $email ) > 254 || mb_strlen( $message ) > 5000 ) {
				return $fail( 'אחד השדות ארוך מדי. אפשר לקצר ולנסות שוב.' );
			}
			// the same rule as the form's own check: 9-13 digits, only digits and phone punctuation
			$digits = strlen( preg_replace( '/\D/', '', $phone ) );
			if ( ! preg_match( '/^[+\d][\d\s\-()]*$/', $phone ) || $digits < 9 || $digits > 13 ) {
				return $fail( 'מספר הטלפון לא תקין. אפשר לכתוב למשל 054-1234567.' );
			}

			// 3 per address per 10 minutes, and 60 in total per hour: enough for any
			// real day of enquiries, and a flood can't fill the inbox or the database.
			$ip = sunrise_client_ip();
			if ( ( $ip && ! sunrise_rate_ok( 'ip-' . $ip, 3, 10 * MINUTE_IN_SECONDS ) ) || ! sunrise_rate_ok( 'global', 60, HOUR_IN_SECONDS ) ) {
				return $fail( 'נשלחו הרבה פניות בזמן קצר. אפשר לנסות שוב בעוד כמה דקות, או ליצור קשר בטלפון.', 429 );
			}

			$post_id = wp_insert_post( [
				'post_type'   => 'contact_message',
				'post_title'  => sprintf( '%s - %s', $name, $phone ),
				'post_status' => 'private', // personal details: never publicly readable, whatever the post type is later set to
				'meta_input'  => [
					'contact_phone'   => $phone,
					'contact_email'   => $email,
					'contact_message' => $message,
				],
			], true );

			if ( is_wp_error( $post_id ) ) {
				return $fail( 'שגיאה בשמירת הפנייה.', 500 );
			}

			$to = apply_filters( 'sunrise_contact_notify_email', get_option( 'admin_email' ) );
			wp_mail(
				$to,
				'פנייה חדשה מהאתר - ' . $name,
				"שם: {$name}\nטלפון: {$phone}\nאימייל: {$email}\n\nהודעה:\n{$message}",
				[ 'Reply-To: ' . $email ]
			);

			return new WP_REST_Response( [ 'success' => true ], 200 );
		},
	] );
} );

/**
 * /projects/ is the "all projects" page: in the order the client set in the
 * dashboard (the same as the home page strip), all of them on one page.
 */
add_action( 'pre_get_posts', function ( $query ) {
	if ( ! is_admin() && $query->is_main_query() && $query->is_post_type_archive( 'project' ) ) {
		$query->set( 'orderby', 'menu_order' );
		$query->set( 'order', 'ASC' );
		$query->set( 'posts_per_page', -1 );
	}
} );

/** Page titles read "Name | Site", the usual form, not "Name – Site". */
add_filter( 'document_title_separator', function () {
	return '|';
} );

/**
 * WordPress only prints a canonical link on single posts. The home page and
 * the projects archive answer to more than one address (?utm=..., trailing
 * variants), so name the one real address.
 */
add_action( 'wp_head', function () {
	if ( is_front_page() ) {
		$url = home_url( '/' );
	} elseif ( is_post_type_archive( 'project' ) ) {
		$url = get_post_type_archive_link( 'project' );
	} else {
		return;
	}
	echo '<link rel="canonical" href="' . esc_url( $url ) . '">' . "\n";
}, 1 );

/**
 * Search-engine sitemap: only pages and projects. The default one also
 * lists every user (author names and ids) and empty blog/taxonomy
 * sections this site doesn't use.
 */
add_filter( 'wp_sitemaps_add_provider', function ( $provider, $name ) {
	return in_array( $name, [ 'users', 'taxonomies' ], true ) ? false : $provider;
}, 10, 2 );
add_filter( 'wp_sitemaps_post_types', function ( $types ) {
	unset( $types['post'] );
	return $types;
} );

/** Logged-out visitors can't list the site's users through the REST API. */
add_filter( 'rest_endpoints', function ( $endpoints ) {
	if ( ! is_user_logged_in() ) {
		foreach ( array_keys( $endpoints ) as $route ) {
			if ( strpos( $route, '/wp/v2/users' ) === 0 ) {
				unset( $endpoints[ $route ] );
			}
		}
	}
	return $endpoints;
} );

/**
 * ...nor by walking ?author=1, 2, 3 (WordPress redirects that to
 * /author/<login>/, which hands out the login names). Logged-out visitors
 * get a plain 404 for it and for any author archive.
 */
add_action( 'template_redirect', function () {
	if ( is_user_logged_in() ) {
		return;
	}
	if ( is_author() || isset( $_GET['author'] ) ) {
		global $wp_query;
		$wp_query->set_404();
		status_header( 404 );
		nocache_headers();
	}
}, 0 );
add_filter( 'redirect_canonical', function ( $redirect ) {
	return isset( $_GET['author'] ) ? false : $redirect;
} );

/**
 * Edits made from the dashboard must show up on the site right away: the
 * pages are served from the host's cache, so flush it whenever a project or
 * a partner logo is saved (the REST hook fires after its meta and image are
 * stored too), trashed or deleted.
 */
foreach ( [ 'project', 'partner' ] as $sunrise_cpt ) {
	add_action( "rest_after_insert_{$sunrise_cpt}", 'sunrise_purge_cache' );
}
foreach ( [ 'trashed_post', 'untrashed_post' ] as $sunrise_hook ) {
	add_action( $sunrise_hook, function ( $post_id ) {
		if ( in_array( get_post_type( $post_id ), [ 'project', 'partner' ], true ) ) {
			sunrise_purge_cache();
		}
	} );
}
// after a hard delete the post is gone, so its type comes from the object WordPress hands over
add_action( 'deleted_post', function ( $post_id, $post = null ) {
	if ( $post && in_array( $post->post_type, [ 'project', 'partner' ], true ) ) {
		sunrise_purge_cache();
	}
}, 10, 2 );
