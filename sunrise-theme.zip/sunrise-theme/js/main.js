    // ---- Mobile nav toggle ----
    const menuToggle = document.getElementById('mobile-menu-toggle');
    const navLinks = document.getElementById('nav-links');
    if (menuToggle && navLinks) {
      menuToggle.addEventListener('click', () => {
        const open = navLinks.classList.toggle('nav-links--open');
        menuToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      });
      navLinks.querySelectorAll('a').forEach(a => {
        a.addEventListener('click', () => {
          navLinks.classList.remove('nav-links--open');
          menuToggle.setAttribute('aria-expanded', 'false');
        });
      });
    }

    const track = document.querySelector('.projects-track');
    const cards = track.querySelectorAll('.project-card');
    document.querySelectorAll('.scroll-arrow').forEach(btn => {
      btn.addEventListener('click', () => {
        // advance by exactly one card + its gap, matching the scroll-snap stops
        const gap = parseFloat(getComputedStyle(track).columnGap) || 0;
        const amount = cards[0].getBoundingClientRect().width + gap;
        track.scrollBy({ left: btn.dataset.dir === 'next' ? amount : -amount, behavior: 'smooth' });
      });
    });

    // True infinite loop: the 5-card set is cloned twice, so scrolling past
    // 05 simply reveals 01/02/... again in a continuous run. When the scroll
    // settles deep inside the last copy, we jump back one whole set-width
    // instantly — the two positions are pixel-identical (the sets repeat),
    // so the jump is invisible and the loop feels endless. Measured after
    // image load, since card widths (and thus the set width) come from the
    // photos' aspect ratios. The rest state stays the original first set.
    window.addEventListener('load', () => {
      const originals = Array.from(track.children);
      for (let i = 0; i < 2; i++) {
        originals.forEach(el => track.appendChild(el.cloneNode(true)));
      }
      const setCount = originals.length;
      // D1: first set's span (its first card has the -10vw rest-state cut,
      // so its span differs); D2: the true period of the repeating sets.
      const D1 = Math.abs(originals[0].offsetLeft - track.children[setCount].offsetLeft);
      const D2 = Math.abs(track.children[setCount].offsetLeft - track.children[setCount * 2].offsetLeft);
      track.addEventListener('scrollend', () => {
        const pos = Math.abs(track.scrollLeft);
        if (pos >= D1 + D2) {
          const sign = track.scrollLeft <= 0 ? -1 : 1;
          track.scrollTo({ left: sign * (pos - D2), behavior: 'instant' });
        }
      });
    });

    // Only the PROJECT word (.projects-bg-text) moves — driven purely by
    // the page's own vertical scroll position. As scrollY grows, it drifts
    // further right-to-left. No cap, no other element touched.
    const bgText = document.querySelector('.projects-bg-text');
    const PARALLAX_FACTOR = 0.05;
    const BASE_SHIFT = 120; // px — starting position shifted right so the "S" is hidden at rest
    function updateBgTextParallax() {
      // centering is handled by margin:0 auto in CSS; BASE_SHIFT nudges the
      // resting position right (hiding the S), and scrolling subtracts from
      // that, sliding it back left to reveal it.
      const offset = window.scrollY * PARALLAX_FACTOR;
      bgText.style.transform = `translateX(${BASE_SHIFT - offset}px)`;
    }
    window.addEventListener('scroll', updateBgTextParallax);
    updateBgTextParallax();

    // Same idea for the ABOUT word, but drifting right as the page scrolls
    // down (opposite direction from the PROJECT word).
    const aboutBgText = document.querySelector('.about-bg-text');
    function updateAboutBgTextParallax() {
      const offset = window.scrollY * PARALLAX_FACTOR;
      aboutBgText.style.transform = `translateX(${offset}px)`;
    }
    window.addEventListener('scroll', updateAboutBgTextParallax);
    updateAboutBgTextParallax();

    // ---- Partners logo strip: continuous run, right to left ----
    // One rAF loop owns the position; the constant drift and the arrows both
    // just move the same `offset` number. Doing it this way (rather than a
    // CSS animation for the run plus scrollBy/transition for the arrows)
    // means the two can never fight over the same transform — an arrow press
    // lands as a nudge the run carries on from, instead of interrupting it.
    const pTrack = document.querySelector('.partners-track');
    const pViewport = document.querySelector('.partners-viewport');
    if (pTrack && pViewport) {
      const SPEED = 38;          // px per second, leftward
      const CATCH_UP = 0.12;     // share of the remaining arrow nudge consumed per frame — an ease-out, no easing curve needed
      const sourceSet = [...pTrack.children];
      const SET_COUNT = sourceSet.length;
      let setWidth = 0, offset = 0, nudge = 0, lastTs = 0;
      const reduce = matchMedia('(prefers-reduced-motion: reduce)');

      // Repeat the set until the strip covers its window plus one whole
      // extra set. The loop below resets by exactly one set-width, so the
      // strip has to still reach the right-hand edge at the instant it
      // resets — otherwise the wrap shows as a gap sliding through.
      const build = () => {
        while (pTrack.children.length > SET_COUNT) pTrack.lastElementChild.remove();
        setWidth = sourceSet.reduce((sum, el) => sum + el.getBoundingClientRect().width, 0);
        if (!setWidth) return;
        const copies = Math.ceil(pViewport.getBoundingClientRect().width / setWidth) + 1;
        for (let i = 0; i < copies; i++) {
          sourceSet.forEach(el => {
            const clone = el.cloneNode(true);
            clone.setAttribute('aria-hidden', 'true'); // same logos again — announce each partner once, not once per copy
            pTrack.appendChild(clone);
          });
        }
      };

      const frame = ts => {
        const dt = lastTs ? Math.min((ts - lastTs) / 1000, 0.1) : 0; // capped so a background tab doesn't resume with one huge jump
        lastTs = ts;
        if (setWidth) {
          if (!reduce.matches) offset -= SPEED * dt; // time-based, so the speed is the same on any refresh rate
          if (nudge) {
            const step = nudge * CATCH_UP;
            offset += step;
            nudge -= step;
            if (Math.abs(nudge) < 0.5) nudge = 0; // settle instead of chasing an ever-smaller remainder forever
          }
          // Fold back into (-setWidth, 0]. The strip is identical every
          // setWidth px, so this is invisible — and it keeps the translate
          // from growing without bound on a page left open.
          offset = ((offset % setWidth) - setWidth) % setWidth;
          pTrack.style.transform = `translateX(${offset.toFixed(2)}px)`;
        }
        requestAnimationFrame(frame);
      };

      document.querySelectorAll('.partners-arrow').forEach(btn => {
        btn.addEventListener('click', () => {
          // → reveals what's further along the strip (content slides left),
          // ← walks it back — the nudge rides on top of the constant drift.
          const cell = setWidth / SET_COUNT;
          nudge += btn.dataset.dir === 'next' ? -cell : cell;
        });
      });

      let resizeTimer;
      addEventListener('resize', () => {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(build, 150); // cells are vw-based, so the set width changes with the viewport
      });

      build();
      requestAnimationFrame(frame);
    }

    // ---- Hero "sketch → build" canvas intro ----
    // Phase 1: the pencil drawing materializes along a moving pencil path
    // (zigzag passes climbing the building bottom-to-top) — real drawing
    // action, not a fade and not a sliding band.
    // Phase 2: the BUILDING ALONE is painted first — soft translucent
    // brush passes spanning just its width, climbing bottom-to-top,
    // erasing the pencil under them as they lay color down. Phase 3:
    // the surroundings (greenery/sky) fill in after with full-width
    // passes of the same soft brush. No bristle texture, no ragged
    // edges — coverage builds up from overlapping translucent bands,
    // which is what reads as gentle wet paint.
    // The DOM color layers hold the final state; they're hidden during
    // .intro and swap in seamlessly when the canvases finish.
    (() => {
      if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;

      const frame = document.querySelector('.hero-frame');
      // The canvases' CSS box is the same box as the building-top image:
      // on desktop that's the frame's full width at the photo's ratio; on
      // mobile (tall hero, see style.css) the layers are instead scaled to
      // the frame's HEIGHT and overflow it sideways, so the box's width is
      // height * 1794/752. Backing-store resolution and the resize guard
      // both key off this one measure, so they stay right either way.
      const isMobile = matchMedia('(max-width: 900px)').matches;
      const boxCssWidth = () => {
        const r = frame.getBoundingClientRect();
        return isMobile ? r.height * BOX.w / BOX.h : r.width;
      };
      const BOX = { w: 1794, h: 752 };                       // canvas coordinate space
      const SKETCH = { x: -0.1547, y: -0.0061, w: 1.0775 };  // building-sketch2.jpg mapped so its building sits exactly on the photo's (see git history: measured anchors, scale 0.604)
      // The pencil path's own bbox and the paint-clip bbox (BX0/BX1/BY0/BY1,
      // below) used to be two SEPARATE, slightly mismatched numbers — the
      // paint region reached a sliver further than the pencil ever had
      // (worst at the top: paint started at y0=0.02, pencil only at
      // y0=0.037). That sliver got painted without ever having been drawn
      // first, which is exactly what broke the "sketch becomes the
      // building" continuity — a bit of the result had no sketch to
      // transform FROM. One shared box now drives both.
      const BLD = { x0: 0.05, x1: 0.60, y0: 0.02, y1: 0.99 };
      // fill0 used to start at 3150 — BEFORE bldg1 (3250) even finished,
      // let alone before the building's own settle-to-opaque grace period
      // was done. The landscape sweep was already visibly running while
      // the building (especially its top, the last part the seeds reach)
      // was still finishing — reading as the top "popping in" together
      // with the green rather than the building completing first. fill0
      // now starts only once the building is FULLY settled.
      // fill0 == bldg1 + the building's own settle grace period (490),
      // exactly — zero pause between "building fully solid" and "green
      // starts rising," per the brief. The settle period itself stays a
      // real fade, not a quick snap — the building's sketch fades out
      // (and its color deepens to final) gradually across that window,
      // not instantly, per the brief that it should disappear "slowly."
      // Trimmed a second time (~18% on top of the first pass, was
      // pencil0:80, pencil1:1300, bldg0:1400, bldg1:2350, fill0:2950,
      // fill1:3850, done:4100 — 4.1s total): still bounce-risk territory,
      // and per the brief this pass should read as "a little faster, and
      // gentle" — every phase scaled down together (not just chopped off
      // the end) so the pacing between them, and the gradual settle in
      // particular, still feels smooth rather than rushed.
      // Mobile runs the building phase and its settle a little longer and
      // lays colour down thinner per pass: the building is ~2.5x bigger
      // on screen there (tall hero, zoomed), so the same pacing sweeps the
      // eye's field faster and the sketch→colour change read as abrupt.
      // Phase ratios are kept; the headline fade-in delay in style.css
      // (mobile block) is scaled to match (0.685 of done, as on desktop).
      const T = isMobile
        ? { pencil0: 60, pencil1: 1060, bldg0: 1140, bldg1: 2300, fill0: 2900, fill1: 3650, done: 3870 }
        : { pencil0: 60, pencil1: 1060, bldg0: 1140, bldg1: 1920, fill0: 2410, fill1: 3150, done: 3360 };
      const RING_A = isMobile ? 0.035 : 0.05;  // per-pass ring alpha (see the paint pass below)
      const CORE_A = isMobile ? 0.11 : 0.16;   // per-pass core alpha

      const srcs = {
        sketch: sunriseTheme.imagesUrl + '/building-sketch2.jpg',
        top: sunriseTheme.imagesUrl + '/building-top.png',
        bottom: sunriseTheme.imagesUrl + '/building-bottom.png'
      };
      const imgs = {};
      const loads = Object.entries(srcs).map(([k, s]) => new Promise(res => {
        const im = new Image();
        im.onload = () => { imgs[k] = im; res(); };
        im.onerror = res; // a failed load just skips the intro below
        im.src = s;
      }));

      frame.classList.add('intro');

      Promise.all(loads).then(() => {
        if (!imgs.sketch || !imgs.top || !imgs.bottom) { frame.classList.remove('intro'); return; }

        // 1.5 is plenty on desktop (the box is ~1800 CSS px wide and W caps at
        // 2400 anyway). On mobile the box is zoomed so the visible part is
        // ~1:1 with device pixels, and phones are 2-3x — at 1.5 the sketch
        // was being upscaled and read as soft. 2400 cap still applies.
        const dpr = Math.min(devicePixelRatio || 1, isMobile ? 2.5 : 1.5);
        const cssW = boxCssWidth();
        const W = Math.min(Math.round(cssW * dpr), 2400);
        const H = Math.round(W * BOX.h / BOX.w);

        const mk = (cls) => {
          const c = document.createElement('canvas');
          c.width = W; c.height = H;
          c.className = 'build-canvas' + (cls ? ' ' + cls : '');
          frame.appendChild(c);
          return c;
        };
        const off = () => { const c = document.createElement('canvas'); c.width = W; c.height = H; return c; };

        const cvSketch = mk('build-canvas--sketch');
        const cvPaint = mk('');
        const xS = cvSketch.getContext('2d'), xP = cvPaint.getContext('2d');

        // the surroundings layer (greenery/sky) pre-rendered once inside the
        // rounded hero-clip rect; the building cutout (imgs.top) stays a
        // separate layer — the two get painted in at DIFFERENT times, the
        // building first, the surroundings after
        const sceneBottom = off(); {
          const g = sceneBottom.getContext('2d');
          const clip = document.querySelector('.hero-clip');
          const rad = (parseFloat(getComputedStyle(clip).borderTopLeftRadius) || 24) * (W / cssW);
          const fy = H * (BOX.h - 605) / BOX.h; // hero-clip top inside the box (frame is 605 tall, bottom-aligned)
          const fh = H - fy;
          if (isMobile) {
            // On the tall mobile hero the strip above the bottom photo is
            // INSIDE the frame (on desktop it's the roof poking above the
            // card), and the finished DOM state fills it with a sky colour
            // (style.css). Paint the same sky here so the surroundings
            // wash reveals it like the rest of the scene and the final
            // swap has nothing to pop in.
            const sky = g.createLinearGradient(0, 0, 0, fy);
            sky.addColorStop(0, '#6b90b6');
            sky.addColorStop(1, '#5e83a9');
            g.fillStyle = sky;
            g.fillRect(0, 0, W, fy + 1);
          }
          g.save();
          g.beginPath();
          g.roundRect(0, fy, W, fh, rad);
          g.clip();
          g.drawImage(imgs.bottom, 0, fy, W, fh);
          g.restore();
        }

        // pencil path: zigzag passes over the building, ground → roof
        const pts = []; {
          const x0 = BLD.x0 * W, x1 = BLD.x1 * W, y0 = BLD.y0 * H, y1 = BLD.y1 * H;
          const passes = 13, step = W * 0.008; /* pass spacing ~62px vs ~90px brush coverage — passes overlap, no white banding between them */
          for (let i = 0; i < passes; i++) {
            const yBase = y1 - (i + 0.5) * (y1 - y0) / passes;
            const ltr = i % 2 === 0;
            for (let x = ltr ? x0 : x1; ltr ? x <= x1 : x >= x0; x += ltr ? step : -step) {
              const wob = Math.sin(x * 0.012 + i * 2.4) * H * 0.022 + (Math.random() - 0.5) * H * 0.006;
              pts.push([x, yBase + wob]);
            }
          }
        }

        // A HYBRID reveal: a soft rising DIM/WASH (bottom-to-top, front edge
        // organically noisy per-column instead of a straight line, with a
        // faint "mist" anticipating just ahead of it) plus scattered
        // irregular PAINT-TOUCH blobs riding along the front — the wash
        // alone read as a mechanical straight band; the blobs alone read as
        // bubbles. Together: dimming that isn't a flat gradient, texture
        // that isn't discrete shapes. Both are recomputed FRESH every frame
        // from (t, progress) — not accumulated stroke-by-stroke — so the
        // result is exactly reproducible at any instant (this is also what
        // let the frozen-time screenshots below actually diagnose it).
        const mkWash = (x0, x1, yTop, yBot, colStep, nBlobs) => {
          const span = x1 - x0, regionH = yBot - yTop, colCount = Math.round(span / colStep);
          const cols = [];
          for (let i = 0; i <= colCount; i++) {
            cols.push({
              x: x0 + span * i / colCount,
              // two low-frequency sine octaves + a random jitter term — an
              // organic, non-repeating front line instead of a straight edge
              noise: (Math.sin(i * 0.5 + Math.random() * 10) * 0.6
                    + Math.sin(i * 1.7 + Math.random() * 10) * 0.3
                    + (Math.random() - 0.5) * 0.5) * regionH * 0.065
            });
          }
          const blobs = [];
          for (let i = 0; i < nBlobs; i++) {
            const spawnP = 0.04 + Math.random() * 0.86;
            const rBase = regionH * (0.055 + Math.random() * 0.05);
            const nPts = 7 + (Math.random() * 3 | 0);
            const pts = [];
            for (let k = 0; k < nPts; k++) {
              const ang = (k / nPts) * Math.PI * 2;
              const rad = rBase * (0.65 + Math.random() * 0.6);
              pts.push([Math.cos(ang) * rad, Math.sin(ang) * rad * (0.7 + Math.random() * 0.3)]);
            }
            blobs.push({
              x: x0 + Math.random() * span,
              y: yBot - spawnP * regionH + (Math.random() - 0.5) * regionH * 0.07,
              pts,
              spawnP,
              fadeP: 0.05 + Math.random() * 0.05,
              alpha: 0.2 + Math.random() * 0.16,
              blur: rBase * 0.35
            });
          }
          return { x0, x1, yTop, yBot, regionH, colW: span / colCount, cols, blobs };
        };
        // Building: paint spreads INWARD from several points at once — like
        // a painter working a canvas from a few directions rather than one
        // edge sweeping across — three irregular blobs grow from fixed
        // seed points and merge into full coverage as they expand.
        const mkSeed = (x, y, maxR) => {
          const nPts = 10 + (Math.random() * 3 | 0);
          const pts = [];
          for (let k = 0; k < nPts; k++) {
            const ang = (k / nPts) * Math.PI * 2;
            // gentle unit-circle jitter — the earlier 0.72–1.22 range (a
            // ±25% swing) read as a jagged amoeba while still small and
            // isolated, before the seeds had grown enough to merge; ±8%
            // stays a soft, natural-looking blob at every size, and at
            // full growth still reads as organic rather than a perfect
            // circle
            const rad = 0.92 + Math.random() * 0.16;
            pts.push([Math.cos(ang) * rad, Math.sin(ang) * rad]);
          }
          return { x, y, pts, maxR };
        };
        const BX0 = BLD.x0 * W, BX1 = BLD.x1 * W, BY0 = BLD.y0 * H, BY1 = BLD.y1 * H; // same box the pencil path uses — see the BLD comment above
        const bSpan = BX1 - BX0, bH = BY1 - BY0, bDiag = Math.hypot(bSpan, bH);
        // maxR is generous (not a tight fit to the bbox) on purpose: each
        // seed's own outer rings are a soft fade, not solid, so the truly
        // OPAQUE reach of a seed is well short of its nominal maxR. At the
        // old tighter radii, corners (the top especially, farthest from
        // every seed) never fully solidified even at p=1 — the sketch kept
        // showing faintly through, which is exactly the "uneven, not the
        // whole building" look flagged. Overshooting is free: paintSeeds
        // already hard-clips to the building's own bbox, so any excess
        // growth past the edges is simply discarded, not visible.
        const bldgSeeds = [
          mkSeed(BX0 + bSpan * 0.16, BY1 - bH * 0.08, bDiag * 0.95), // bottom-left
          mkSeed(BX1 - bSpan * 0.14, BY1 - bH * 0.10, bDiag * 0.95), // bottom-right
          mkSeed(BX0 + bSpan * 0.55, BY0 + bH * 0.14, bDiag * 0.9)   // upper-middle
        ];
        // Landscape: rises diagonally from the bottom-left corner across
        // the whole frame instead of a level front — per the brief, this
        // comes in AFTER the building, sweeping over it. Still built with
        // mkWash for its x0/x1/yTop/yBot bounds; its .cols/.noise/.blobs go
        // unused — see paintDiagonalWash below, a plain linear-gradient
        // sweep instead of the skyline-ramp technique (0 blobs: the
        // paint-touch texture read as a wide disconnected haze ahead of
        // the diagonal edge — see paintDiagonalWash's comment).
        const fillWash = mkWash(-W * 0.04, W * 1.04, H * 0.01, H, W * 0.009, 0);

        const maskPencil = off(), maskBldg = off(), maskFill = off();
        const gPen = maskPencil.getContext('2d'), gBldg = maskBldg.getContext('2d'), gFill = maskFill.getContext('2d');
        // per-frame working buffers for the two independently-masked color layers
        const bufBldg = off(), bufFill = off();
        const xBB = bufBldg.getContext('2d'), xBF = bufFill.getContext('2d');

        const brush = (g, x, y, r) => {
          const rg = g.createRadialGradient(x, y, 0, x, y, r);
          rg.addColorStop(0, 'rgba(0,0,0,0.85)');
          rg.addColorStop(0.7, 'rgba(0,0,0,0.5)');
          rg.addColorStop(1, 'rgba(0,0,0,0)');
          g.fillStyle = rg;
          g.beginPath(); g.arc(x, y, r, 0, 7); g.fill();
        };
        const drawBlobPath = (g, cx, cy, pts) => {
          const n = pts.length, mid = (a, b) => [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
          const m0 = mid(pts[n - 1], pts[0]);
          g.beginPath();
          g.moveTo(cx + m0[0], cy + m0[1]);
          for (let i = 0; i < n; i++) {
            const p1 = pts[i], m = mid(p1, pts[(i + 1) % n]);
            g.quadraticCurveTo(cx + p1[0], cy + p1[1], cx + m[0], cy + m[1]);
          }
          g.closePath();
        };
        // Landscape fill: a diagonal sweep from the bottom-left corner
        // across the whole frame. Tried building this with the same
        // per-column skyline+ramp technique as the level wash above (just
        // adding a linear tilt to each column's front) — with a slant this
        // steep the ramp's fixed-vertical-offset layers no longer align
        // into a smooth gradient, they show up as visible concentric
        // rings/waves. A single canvas linearGradient along the diagonal
        // axis is analytically smooth — no layering, so no rings possible
        // — and is the geometrically correct tool for a straight sweep
        // anyway (the organic noisy-edge look was for the level wash;
        // this one is meant to read as one clean diagonal line).
        const paintDiagonalWash = (g, w, p) => {
          if (p <= 0.001) return;
          const spanW = w.x1 - w.x0, spanH = w.yBot - w.yTop, diagLen = Math.hypot(spanW, spanH);
          const feather = diagLen * 0.13; // a soft edge, but not too wide — this is what the client sees rise across the frame, so it should read as one clean line, not a wide fade
          const ux = spanW / diagLen, uy = -spanH / diagLen; // unit vector toward the top-right corner (canvas y grows downward)
          const travel = -feather + p * (diagLen + feather * 2);
          const bx = w.x0 + ux * travel, by = w.yBot + uy * travel;
          const grad = g.createLinearGradient(bx, by, bx + ux * feather, by + uy * feather);
          grad.addColorStop(0, 'rgba(0,0,0,0.85)');
          grad.addColorStop(1, 'rgba(0,0,0,0)');
          g.fillStyle = grad;
          g.fillRect(w.x0 - 60, w.yTop - 60, spanW + 120, spanH + 120);
          // No paint-touch blobs here (unlike the building's texture) —
          // this layer reads as one clean diagonal sweep, not brushwork.
        };
        // Building fill: each seed grows from 0 to its own maxR, drawn as
        // several nested copies of its (fixed, irregular) blob shape at
        // shrinking radius fractions, all at low alpha — the same layered-
        // ring softening as the skyline ramp above, just radial: coverage
        // stacks up densest at the seed's center and fades toward its
        // growing edge, and where two seeds' blobs overlap they naturally
        // merge into one denser region instead of showing a seam.
        // Softens whatever's already drawn near a hard clip rect's four
        // edges, down to transparent right at the boundary — two
        // destination-in gradient passes (x then y) multiplied together.
        // Used after anything clipped to the building's footprint, so the
        // clip line (still needed to keep paint off the trees beside it)
        // lands on already-faded pixels instead of slicing through solid
        // color into a hard, ruler-straight edge.
        const featherClipEdges = (g, clip) => {
          // 0.3 (30% of the building's own width/height!) was almost
          // certainly meant to be 0.03 — at 30%, the fade-to-zero zone
          // swallowed the whole top third of the building (nearest BY0),
          // which is exactly why it never looked fully, uniformly
          // painted no matter how solid the seeds/settle made it
          // underneath: this multiplies it back down to near-transparent
          // right after. 3% keeps just enough softening to avoid a
          // ruler-straight clip line without eating a third of the
          // building.
          const fx = (clip.x1 - clip.x0) * 0.03, fy = (clip.y1 - clip.y0) * 0.03;
          g.globalCompositeOperation = 'destination-in';
          const gx = g.createLinearGradient(clip.x0, 0, clip.x1, 0);
          const fx0 = fx / (clip.x1 - clip.x0), fx1 = 1 - fx0;
          gx.addColorStop(0, 'rgba(0,0,0,0)');
          gx.addColorStop(fx0, 'rgba(0,0,0,1)');
          gx.addColorStop(fx1, 'rgba(0,0,0,1)');
          gx.addColorStop(1, 'rgba(0,0,0,0)');
          g.fillStyle = gx;
          g.fillRect(clip.x0, clip.y0, clip.x1 - clip.x0, clip.y1 - clip.y0);
          const gy = g.createLinearGradient(0, clip.y0, 0, clip.y1);
          const fy0 = fy / (clip.y1 - clip.y0), fy1 = 1 - fy0;
          gy.addColorStop(0, 'rgba(0,0,0,0)');
          gy.addColorStop(fy0, 'rgba(0,0,0,1)');
          gy.addColorStop(fy1, 'rgba(0,0,0,1)');
          gy.addColorStop(1, 'rgba(0,0,0,0)');
          g.fillStyle = gy;
          g.fillRect(clip.x0, clip.y0, clip.x1 - clip.x0, clip.y1 - clip.y0);
          g.globalCompositeOperation = 'source-over';
        };
        const paintSeeds = (g, seeds, p, clip) => {
          if (p <= 0.001) return;
          const grow = Math.pow(p, 0.6); // front-loaded — the seeds reach a mutually-overlapping size fast, so there's only a brief moment where they read as separate spots rather than one spreading fill
          const RING = 5;
          // clip to the building's own footprint: the blobs' whole point is
          // to merge into one continuous fill with no gaps, so their radii
          // comfortably overshoot the building's edges — left unclipped
          // that overshoot colors the trees beside it well before the
          // landscape phase gets there, which read as the paint "leaking"
          // out of the building into the greenery.
          if (clip) { g.save(); g.beginPath(); g.rect(clip.x0, clip.y0, clip.x1 - clip.x0, clip.y1 - clip.y0); g.clip(); }
          for (const s of seeds) {
            const R = grow * s.maxR;
            if (R <= 0) continue;
            for (let i = RING; i >= 1; i--) {
              const frac = 0.7 + 0.3 * (i / RING);
              const scaled = s.pts.map(([dx, dy]) => [dx * R * frac, dy * R * frac]);
              drawBlobPath(g, s.x, s.y, scaled);
              g.fillStyle = 'rgba(0,0,0,' + RING_A + ')';
              g.fill();
            }
            // Deliberately NOT fully opaque: per the brief, the sketch
            // should keep showing faintly THROUGH the color while it's
            // being painted — "colored-in drawing," not a photo swapped
            // on top of it — settling to true full opacity (and the
            // sketch actually clearing) only happens later, via settle()
            // below, once this whole phase is done. Both this and the
            // rings above are much lower alpha than they look like they
            // "should" need: the three seeds' soft reach deliberately
            // overlaps a lot (see maxR above), and stacked normal
            // compositing pushes overlapping alpha up fast — two seeds at
            // 0.35 each already compose to ~0.58, three to ~0.72. Low
            // per-seed alpha is what keeps the OVERLAPPED regions (most
            // of the building, once seeds have grown a while) reading as
            // translucent color over a visible sketch instead of solid
            // paint — the building "being drawn," not swapped in solid.
            const core = s.pts.map(([dx, dy]) => [dx * R * 0.7, dy * R * 0.7]);
            drawBlobPath(g, s.x, s.y, core);
            g.fillStyle = 'rgba(0,0,0,' + CORE_A + ')';
            g.fill();
          }
          // feather the paint down to nothing well BEFORE the hard clip
          // line, so the clip lands on already-transparent pixels instead
          // of slicing through solid color — without this, once the blobs
          // grow large enough to blanket the whole footprint, the clip
          // rect itself became the visible edge: a straight, hard-cut line
          // down each side, not a soft one.
          if (clip) { featherClipEdges(g, clip); g.restore(); }
        };
        // after a phase's wash reaches p=1, float its mask the rest of the
        // way to fully opaque so no residual translucency pops when the
        // next layer (or the DOM swap) lands — a gradual "settling"
        //
        // THE BUG THAT CAUSED THE WIDE "GHOST" HAZE (root-caused via direct
        // getImageData readback of maskBldg, after ruling out blend-mode,
        // filter, isolation, GPU/software rendering, blobs, DOM visibility,
        // and even hard-clipping the fill layer — none of which touched
        // it, because none of them were the actual source): this used to
        // fillRect the WHOLE canvas (0,0,W,H) unconditionally. Called on
        // gBldg, that painted a faint rgba(0,0,0,0.3) wash across the
        // ENTIRE frame — including all the sky and trees far outside the
        // building's clip — regardless of what the paint pass itself clipped
        // to. That stray ~30%-alpha layer, composited into imgs.top via
        // maskBldg, is exactly what was showing as the wide translucent
        // "ghost" of the photo well ahead of the real diagonal edge.
        const settle = (g, t, tEnd, tFull, clip) => {
          if (t <= tEnd) return;
          const a = Math.min((t - tEnd) / (tFull - tEnd), 1);
          // ramps all the way to a=1 (fully opaque), not just a partial
          // top-up — now that paintSeeds' own alpha is deliberately kept
          // low (so the sketch shows through while painting), the seeds
          // alone no longer reach solid opacity even at p=1, so settle is
          // what carries the mask the REST of the way to fully solid —
          // the "color darkens, sketch brightens and disappears" beat.
          g.fillStyle = 'rgba(0,0,0,' + a.toFixed(3) + ')';
          if (clip) { g.save(); g.beginPath(); g.rect(clip.x0, clip.y0, clip.x1 - clip.x0, clip.y1 - clip.y0); g.clip(); }
          g.fillRect(0, 0, W, H);
          if (clip) { featherClipEdges(g, clip); g.restore(); }
        };

        const easeIO = t => t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
        let penIdx = 0, painting = false;
        const t0 = performance.now();

        const tick = now => {
          const t = now - t0;

          if (t >= T.pencil0 && penIdx < pts.length) {
            const p = Math.min((t - T.pencil0) / (T.pencil1 - T.pencil0), 1);
            const target = Math.round(easeIO(p) * pts.length);
            const r = W * 0.032;
            for (; penIdx < target; penIdx++) brush(gPen, pts[penIdx][0], pts[penIdx][1], r);
          }
          // both mask canvases are cleared EVERY tick unconditionally, even
          // before their own phase starts — headless Chromium crashed
          // (screenshot silently never wrote, verified deterministic across
          // 6+ repro attempts) when a canvas that had NEVER had any 2D
          // context operation performed on it was read as a destination-in
          // source below; an untouched-but-blank one from clearRect alone
          // was fine. Costs nothing (clearRect on an already-empty canvas
          // is trivial) and removes the pristine-canvas state entirely.
          gBldg.clearRect(0, 0, W, H);
          gFill.clearRect(0, 0, W, H);
          if (t >= T.bldg0) {
            painting = true;
            paintSeeds(gBldg, bldgSeeds, Math.min((t - T.bldg0) / (T.bldg1 - T.bldg0), 1), { x0: BX0, y0: BY0, x1: BX1, y1: BY1 });
            settle(gBldg, t, T.bldg1, T.bldg1 + 490, { x0: BX0, y0: BY0, x1: BX1, y1: BY1 });
          }
          if (t >= T.fill0) {
            paintDiagonalWash(gFill, fillWash, Math.min((t - T.fill0) / (T.fill1 - T.fill0), 1));
            settle(gFill, t, T.fill1, T.done);
          }

          // sketch canvas = drawing × pencil-mask, minus everything painted over
          xS.clearRect(0, 0, W, H);
          xS.drawImage(imgs.sketch, SKETCH.x * W, SKETCH.y * H, SKETCH.w * W, SKETCH.w * W * imgs.sketch.height / imgs.sketch.width);
          xS.globalCompositeOperation = 'destination-in';
          xS.drawImage(maskPencil, 0, 0);
          if (painting) {
            xS.globalCompositeOperation = 'destination-out';
            xS.drawImage(maskFill, 0, 0);
            // Erasing the building's own sketch from the raw growth mask
            // (maskBldg) used to wipe it out from painting's very first
            // instant — paintSeeds' blobs carry SOME alpha as soon as
            // they exist, however faint, so the sketch never actually
            // stayed visible under the translucent color the way the
            // brief wants: color landing on a drawing that's still there,
            // not on blank paper. Instead, the sketch now stays fully
            // intact through the whole growth phase (bldg0→bldg1) and
            // only fades here, tied to the building's OWN settle ramp —
            // 0 through growth, 0→1 across the 800ms settle after — so it
            // clears gradually, in step with the color deepening to
            // final, not instantly at the first brushstroke.
            const bldgSettleA = t > T.bldg1 ? Math.min((t - T.bldg1) / 490, 1) : 0;
            if (bldgSettleA > 0) {
              // the pencil brush has real width (r = W*0.032), so strokes
              // near the building's clip edge can poke a few px past it —
              // paintSeeds only covers exactly inside the clip, so those
              // stray marks would never get touched by it. A flat erase
              // over a slightly WIDER rect (clear past the building on
              // every side) mops them up without needing the paint mask
              // itself to be any less tightly clipped.
              const bleed = W * 0.05;
              xS.fillStyle = 'rgba(0,0,0,' + bldgSettleA.toFixed(3) + ')';
              xS.fillRect(BX0 - bleed, BY0 - bleed, (BX1 - BX0) + bleed * 2, (BY1 - BY0) + bleed * 2);
            }
          }
          xS.globalCompositeOperation = 'source-over';

          // paint canvas: surroundings × fill-mask below, building × its own
          // mask on top — two separately-masked layers composited each frame
          // (masking them on ONE canvas is impossible: destination-in would
          // clip the already-masked other layer too)
          if (painting) {
            xBF.clearRect(0, 0, W, H);
            xBF.drawImage(sceneBottom, 0, 0);
            xBF.globalCompositeOperation = 'destination-in';
            xBF.drawImage(maskFill, 0, 0);
            xBF.globalCompositeOperation = 'source-over';

            xBB.clearRect(0, 0, W, H);
            xBB.drawImage(imgs.top, 0, 0, W, H);
            xBB.globalCompositeOperation = 'destination-in';
            xBB.drawImage(maskBldg, 0, 0);
            xBB.globalCompositeOperation = 'source-over';

            xP.clearRect(0, 0, W, H);
            xP.drawImage(bufFill, 0, 0);
            xP.drawImage(bufBldg, 0, 0);
          }

          if (t < T.done) {
            requestAnimationFrame(tick);
          } else {
            // cross-fade rather than an instant swap — see the .intro
            // comment in the CSS for why an instant cut isn't safe here.
            // classList.remove starts the DOM layer fading in (its own
            // CSS transition); adding --done starts the canvases fading
            // out on the same 0.25s; only once that's actually finished
            // are they removed, so there's no frame where the DOM layer
            // is visible but the (still-solid) canvas hasn't started
            // yielding yet.
            frame.classList.remove('intro');
            cvSketch.classList.add('build-canvas--done');
            cvPaint.classList.add('build-canvas--done');
            setTimeout(() => { cvSketch.remove(); cvPaint.remove(); }, 260);
          }
        };
        requestAnimationFrame(tick);

        // a LARGE resize mid-intro (orientation flip, window drag) would
        // break the pixel mapping — just finish. The 60px threshold is
        // deliberate: the scrollbar appearing during load fires a real
        // ~17-25px resize (measured live: 1754→1779), and reacting to it
        // killed the whole intro; the canvases are %-sized so they track
        // small width shifts on their own, only the raster mapping drifts
        // by an invisible ~1%.
        const onResize = () => {
          if (Math.abs(boxCssWidth() - cssW) < 60) return;
          removeEventListener('resize', onResize);
          frame.classList.remove('intro');
          cvSketch.remove();
          cvPaint.remove();
        };
        addEventListener('resize', onResize);
      });
    })();

    // About stats: count up from 0 to the target once the row scrolls into
    // view. Fast and eased (not linear) so it reads as a quick, pleasant
    // snap rather than a slow mechanical tick — fires once per element via
    // IntersectionObserver, not on every scroll.
    (() => {
      const nums = document.querySelectorAll('.num-value');
      if (!nums.length) return;
      const reduced = matchMedia('(prefers-reduced-motion: reduce)').matches;
      const DURATION = 900;
      const easeOut = t => 1 - Math.pow(1 - t, 3);

      const animate = el => {
        const to = parseInt(el.dataset.countTo, 10);
        if (reduced) { el.textContent = to; return; }
        const t0 = performance.now();
        const tick = now => {
          const p = Math.min((now - t0) / DURATION, 1);
          el.textContent = Math.round(easeOut(p) * to);
          if (p < 1) requestAnimationFrame(tick);
        };
        requestAnimationFrame(tick);
      };

      const io = new IntersectionObserver(entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            animate(entry.target);
            io.unobserve(entry.target);
          }
        });
      }, { threshold: 0.4 });
      nums.forEach(el => io.observe(el));
    })();

    // About text: "written in" cascade, letter by letter (see the .ch
    // rules above) — fires once, same IntersectionObserver-on-scroll-in
    // pattern as the stats counter above.
    (() => {
      const col = document.querySelector('.about-content-col');
      if (!col || matchMedia('(prefers-reduced-motion: reduce)').matches) return;

      // Wraps every character of el's text in its own <span class="ch">,
      // recursing into inline children (e.g. the <strong> spans in the
      // paragraphs) so their letters get wrapped too and keep their
      // bolding — <br> is left alone (nothing to split, and splitting
      // would just be an empty span). Snapshotting childNodes into an
      // array first is required: replacing a text node with its
      // fragment while a live NodeList is mid-iteration skips entries.
      const splitChars = el => {
        [...el.childNodes].forEach(node => {
          if (node.nodeType === Node.TEXT_NODE) {
            const frag = document.createDocumentFragment();
            for (const ch of node.textContent) {
              const span = document.createElement('span');
              span.className = 'ch';
              span.textContent = ch;
              frag.appendChild(span);
            }
            node.replaceWith(frag);
          } else if (node.nodeType === Node.ELEMENT_NODE && node.tagName !== 'BR') {
            splitChars(node);
          }
        });
      };

      const blocks = [
        document.querySelector('.about-header'),
        col.querySelector('h2'),
        ...col.querySelectorAll('.about-body p')
      ].filter(Boolean);
      blocks.forEach(splitChars);

      // Each block starts a little after the previous one (BLOCK_STEP) —
      // a beat between "sentences" — and within a block, each letter
      // lands CHAR_STEP after the one before it. Both are small on
      // purpose: even the longest paragraph here (~140 letters) finishes
      // its own sweep in well under a second, so the whole cascade —
      // label through the last paragraph — is done in well under 2s.
      const BLOCK_STEP = 80, CHAR_STEP = 6;
      blocks.forEach((block, bi) => {
        block.querySelectorAll('.ch').forEach((ch, ci) => {
          ch.style.transitionDelay = (bi * BLOCK_STEP + ci * CHAR_STEP) + 'ms';
        });
      });

      const io = new IntersectionObserver(entries => {
        entries.forEach(entry => {
          if (entry.isIntersecting) {
            col.classList.add('in-view');
            io.unobserve(entry.target);
          }
        });
      }, { threshold: 0.3 });
      io.observe(col);
    })();

    // ---- Contact form ----
    (() => {
      const form = document.getElementById('sunrise-contact-form');
      if (!form) return;
      const status = form.querySelector('.contact-form-status');
      const submitBtn = form.querySelector('.contact-submit');
      const submitLabel = submitBtn.querySelector('.contact-submit-label');

      const setStatus = (text, state) => {
        status.textContent = text;
        if (state) status.setAttribute('data-state', state);
        else status.removeAttribute('data-state');
      };

      form.addEventListener('submit', async e => {
        e.preventDefault();

        const data = {
          name: form.name.value.trim(),
          phone: form.phone.value.trim(),
          email: form.email.value.trim(),
          message: form.message.value.trim(),
          website: form.website.value, // honeypot
        };

        if (!data.name || !data.phone || !data.email) {
          setStatus('נא למלא שם, טלפון ואימייל.', 'error');
          return;
        }
        if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
          setStatus('כתובת האימייל לא תקינה.', 'error');
          return;
        }

        // A filled honeypot means a bot — pretend success, send nothing.
        if (data.website) {
          setStatus('תודה! ההודעה נשלחה.');
          form.reset();
          return;
        }

        submitBtn.disabled = true;
        submitLabel.textContent = 'שולח...';
        setStatus('');

        try {
          const res = await fetch(sunriseTheme.restUrl + 'sunrise/v1/contact', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data),
          });
          const body = await res.json().catch(() => ({}));
          if (!res.ok || !body.success) throw new Error(body.message || 'שגיאה בשליחה');
          setStatus('תודה! ההודעה נשלחה, נחזור אליכם בהקדם.');
          form.reset();
        } catch (err) {
          setStatus('לא הצלחנו לשלוח את ההודעה כרגע. אפשר לנסות שוב, או ליצור קשר בטלפון/ווטסאפ.', 'error');
        } finally {
          submitBtn.disabled = false;
          submitLabel.textContent = 'שליחה';
        }
      });
    })();
