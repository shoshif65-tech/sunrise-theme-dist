<?php
/**
 * Front page template — hero / projects / about / partners / contact.
 */
get_header();
$img_url          = esc_url( get_template_directory_uri() ) . '/images';
$sunrise_contact  = sunrise_contact_urls();
?>
    <section class="hero" id="hero">
      <div class="hero-frame">
        <div class="hero-clip">
          <img class="hero-bg-bottom hero-layer-color" src="<?php echo $img_url; ?>/building-bottom.png" alt="">
        </div>
        <img class="hero-bg-top hero-layer-color" src="<?php echo $img_url; ?>/building-top.png" alt="">
        <div class="bird-wrap bird-1"><img class="bird" src="<?php echo $img_url; ?>/bird-1.png" alt=""></div>
        <div class="bird-wrap bird-2"><img class="bird" src="<?php echo $img_url; ?>/bird-2.png" alt=""></div>
        <div class="bird-wrap bird-3"><img class="bird" src="<?php echo $img_url; ?>/bird-3.png" alt=""></div>
        <div class="bird-wrap bird-4"><img class="bird" src="<?php echo $img_url; ?>/bird-4.png" alt=""></div>
        <div class="bird-wrap bird-5"><img class="bird" src="<?php echo $img_url; ?>/bird-5.png" alt=""></div>

        <div class="hero-content">
          <h1><?php sunrise_content_html( 'hero_title' ); ?></h1>
          <p><?php sunrise_content_html( 'hero_text' ); ?></p>
          <a class="pill-btn hero-cta" href="#contact">
            <?php sunrise_content_html( 'cta_text' ); ?>
            <svg width="24" height="10" viewBox="0 0 24 10" fill="none" aria-hidden="true"><path d="M23 5H1M1 5L4 2.5M1 5L4 7.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" vector-effect="non-scaling-stroke"/></svg>
          </a>
        </div>
      </div>
    </section>

    <section class="projects" id="projects">
      <div class="projects-header">
        <a class="pill-btn nav-cta" href="<?php echo esc_url( get_post_type_archive_link( 'project' ) ); ?>">
          כל הפרויקטים
          <svg width="24" height="10" viewBox="0 0 24 10" fill="none"><path d="M23 5H1M1 5L4 2.5M1 5L4 7.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" vector-effect="non-scaling-stroke"/></svg>
        </a>
        <div class="projects-logo" role="heading" aria-level="2"><span class="dot"></span>פרויקטים</div>
      </div>

      <div class="projects-nav">
        <?php // RTL: the arrow on the LEFT points left = "further along" (the next project), the one on the RIGHT goes back. The data-dir values are what main.js scrolls by - only the spoken labels follow what the arrows look like. ?>
        <button class="scroll-arrow" data-dir="prev" aria-label="לפרויקט הבא">
          <svg width="20" height="12" viewBox="0 0 20 12" fill="none" aria-hidden="true"><path d="M19 6H1M1 6L6 1M1 6L6 11" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </button>
        <button class="scroll-arrow" data-dir="next" aria-label="לפרויקט הקודם">
          <svg width="20" height="12" viewBox="0 0 20 12" fill="none" aria-hidden="true"><path d="M1 6H19M19 6L14 1M19 6L14 11" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg>
        </button>
      </div>

      <div class="projects-bg-wrap">
        <div class="projects-bg-text-clip">
          <div class="projects-bg-text"><img src="<?php echo $img_url; ?>/projects-bg-text.png" alt=""></div>
        </div>

        <div class="projects-track">
<?php
$sunrise_projects = new WP_Query( [
	'post_type'      => 'project',
	'posts_per_page' => -1,
	'orderby'        => 'menu_order',
	'order'          => 'ASC',
] );

if ( $sunrise_projects->have_posts() ) :
	$tiers = [ 'pc-a', 'project-card--featured', 'pc-c' ];
	$i     = 0;
	while ( $sunrise_projects->have_posts() ) :
		$sunrise_projects->the_post();
		$tier     = $tiers[ $i % 3 ];
		$up_class = ( (int) floor( $i / 3 ) % 2 === 1 ) ? ' pc-up' : '';
		$num      = str_pad( $i + 1, 2, '0', STR_PAD_LEFT );
?>
          <a class="project-card <?php echo esc_attr( $tier . $up_class ); ?>" href="<?php echo esc_url( get_permalink() ); ?>">
            <?php if ( has_post_thumbnail() ) : ?>
              <?php the_post_thumbnail( 'large', [ 'class' => 'project-card-image', 'alt' => esc_attr( get_the_title() ) ] ); ?>
            <?php endif; ?>
            <div class="connector"></div>
            <div class="project-card-info">
              <span class="num"><?php echo esc_html( $num ); ?></span>
              <div class="title"><?php the_title(); ?></div>
              <div class="desc"><?php echo esc_html( get_the_excerpt() ); ?></div>
            </div>
          </a>
<?php
		$i++;
	endwhile;
	wp_reset_postdata();
else :
	// No projects added yet in wp-admin — placeholder set, identical to the original design file,
	// so the section never looks empty/broken. Replace by adding real "פרויקט" posts.
?>
          <div class="project-card pc-a">
            <img class="project-card-image" src="<?php echo $img_url; ?>/project-photo-2.jpg" alt="">
            <div class="connector"></div>
            <div class="project-card-info">
              <span class="num">01</span>
              <div class="title">מגדל הירקון</div>
              <div class="desc">מגדל מטורף בעל 40 קומות הוקדם בשנת 20253</div>
            </div>
          </div>

          <div class="project-card project-card--featured">
            <img class="project-card-image" src="<?php echo $img_url; ?>/project-photo-1.jpg" alt="">
            <div class="connector"></div>
            <div class="project-card-info">
              <span class="num">02</span>
              <div class="title">מגדל הירקון</div>
              <div class="desc">מגדל מטורף בעל 40 קומות הוקדם בשנת 20253</div>
            </div>
          </div>

          <div class="project-card pc-c">
            <img class="project-card-image" src="<?php echo $img_url; ?>/project-photo-1.jpg" alt="">
            <div class="connector"></div>
            <div class="project-card-info">
              <span class="num">03</span>
              <div class="title">מגדל הירקון</div>
              <div class="desc">מגדל מטורף בעל 40 קומות הוקדם בשנת 20253</div>
            </div>
          </div>

          <div class="project-card pc-a pc-up">
            <img class="project-card-image" src="<?php echo $img_url; ?>/project-photo-2.jpg" alt="">
            <div class="connector"></div>
            <div class="project-card-info">
              <span class="num">04</span>
              <div class="title">מגדל הירקון</div>
              <div class="desc">מגדל מטורף בעל 40 קומות הוקדם בשנת 20253</div>
            </div>
          </div>

          <div class="project-card project-card--featured pc-up">
            <img class="project-card-image" src="<?php echo $img_url; ?>/project-photo-1.jpg" alt="">
            <div class="connector"></div>
            <div class="project-card-info">
              <span class="num">05</span>
              <div class="title">מגדל הירקון</div>
              <div class="desc">מגדל מטורף בעל 40 קומות הוקדם בשנת 20253</div>
            </div>
          </div>
<?php endif; ?>
        </div>
      </div>
    </section>

    <section class="about" id="about">
      <div class="about-bg-wrap">
        <div class="about-bg-text-clip">
          <div class="about-bg-text"><img src="<?php echo $img_url; ?>/about-bg-text.png" alt=""></div>
        </div>

        <div class="about-grid">
          <div class="about-photo-col">
            <img class="about-photo" src="<?php echo $img_url; ?>/about-portrait.jpg" alt="<?php echo esc_attr( sunrise_content( 'about_person_name' ) ); ?>">
            <div class="about-person">
              <div class="about-person-line"></div>
              <div class="about-person-info">
                <div class="name"><?php sunrise_content_html( 'about_person_name' ); ?></div>
                <div class="title"><?php sunrise_content_html( 'about_person_title' ); ?></div>
              </div>
              <svg class="about-signature" aria-hidden="true" viewBox="0 0 160 46" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M8 34C14 20 20 14 26 20C30 24 26 32 20 34C24 30 34 18 42 22C48 25 40 34 36 36C42 32 56 16 66 22C72 26 62 36 58 36C66 30 82 14 94 22C100 26 90 38 100 30C108 24 120 14 130 20C136 24 128 32 152 12" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/>
              </svg>
            </div>
          </div>

          <div class="about-content-col">
            <div class="about-header">
              <div class="about-logo" role="heading" aria-level="2"><span class="dot"></span>אודות החברה</div>
            </div>

            <h2><?php sunrise_content_html( 'about_heading' ); ?></h2>

            <div class="about-body">
              <p><?php sunrise_content_html( 'about_p1' ); ?></p>
              <p><?php sunrise_content_html( 'about_p2' ); ?></p>
              <p><?php sunrise_content_html( 'about_p3' ); ?></p>

              <div class="about-divider"></div>

              <div class="about-stats">
                <div><span class="num"><span class="num-value" data-count-to="<?php echo esc_attr( sunrise_content( 'about_stat1_value' ) ); ?>">0</span>%</span><span class="label"><?php sunrise_content_html( 'about_stat1_label' ); ?></span></div>
                <div><span class="num"><span class="num-value" data-count-to="<?php echo esc_attr( sunrise_content( 'about_stat2_value' ) ); ?>">0</span>+</span><span class="label"><?php sunrise_content_html( 'about_stat2_label' ); ?></span></div>
                <div><span class="num"><span class="num-value" data-count-to="<?php echo esc_attr( sunrise_content( 'about_stat3_value' ) ); ?>">0</span>+</span><span class="label"><?php sunrise_content_html( 'about_stat3_label' ); ?></span></div>
                <div><span class="num"><span class="num-value" data-count-to="<?php echo esc_attr( sunrise_content( 'about_stat4_value' ) ); ?>">0</span></span><span class="label"><?php sunrise_content_html( 'about_stat4_label' ); ?></span></div>
              </div>

              <a class="pill-btn about-cta" href="#contact">
                <?php sunrise_content_html( 'cta_text' ); ?>
                <svg width="24" height="10" viewBox="0 0 24 10" fill="none" aria-hidden="true"><path d="M23 5H1M1 5L4 2.5M1 5L4 7.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" vector-effect="non-scaling-stroke"/></svg>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="partners" id="partners">
      <div class="partners-top">
        <div class="partners-badge">
          <div class="partners-badge-circle"><?php sunrise_content_html( 'partners_badge_number' ); ?></div>
          <div class="partners-badge-divider"></div>
          <div class="partners-badge-text"><?php sunrise_content_html( 'partners_badge_text' ); ?></div>
        </div>
        <div class="partners-header">
          <div class="partners-logo" role="heading" aria-level="2"><span class="dot"></span>שיתופי פעולה</div>
          <p class="partners-subtitle"><?php sunrise_content_html( 'partners_subtitle' ); ?></p>
        </div>
      </div>

<?php
$sunrise_partners = new WP_Query( [
	'post_type'      => 'partner',
	'post_status'    => 'publish',
	'posts_per_page' => -1,
	'orderby'        => 'menu_order',
	'order'          => 'ASC',
	'no_found_rows'  => true,
] );
// No logos at all (e.g. the client removed every one): leave the whole
// strip out instead of showing an empty black box with arrows.
if ( $sunrise_partners->have_posts() ) :
?>
      <div class="partners-box-wrap">
        <div class="partners-box">
          <button class="partners-arrow" data-dir="prev" aria-label="הלוגו הקודם">
            <svg width="58" height="12" viewBox="0 0 58 12" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M56.75 4.77295C57.1642 4.77295 57.5 5.10874 57.5 5.52295C57.5 5.93716 57.1642 6.27295 56.75 6.27295L56.75 5.52295L56.75 4.77295ZM0.219669 6.05327C-0.0732231 5.76038 -0.0732231 5.28551 0.219669 4.99261L4.99264 0.219644C5.28553 -0.0732495 5.76041 -0.0732495 6.0533 0.219644C6.3462 0.512537 6.3462 0.987411 6.0533 1.2803L1.81066 5.52294L6.0533 9.76559C6.34619 10.0585 6.34619 10.5334 6.0533 10.8262C5.76041 11.1191 5.28553 11.1191 4.99264 10.8262L0.219669 6.05327ZM56.75 5.52295L56.75 6.27295L0.75 6.27294L0.75 5.52294L0.75 4.77294L56.75 4.77295L56.75 5.52295Z" fill="currentColor"/></svg>
          </button>

          <div class="partners-viewport">
            <div class="partners-track">
<?php foreach ( $sunrise_partners->posts as $p ) :
	$logo = get_the_post_thumbnail_url( $p->ID, 'medium' );
	if ( ! $logo ) {
		continue;
	}
	$white_class = sunrise_partner_is_white( $p->ID ) ? ' is-white' : '';
?>
              <div class="partner-logo"><img class="<?php echo esc_attr( trim( $white_class ) ); ?>" src="<?php echo esc_url( $logo ); ?>" alt="<?php echo esc_attr( get_the_title( $p ) ); ?>"></div>
<?php endforeach; ?>
            </div>
          </div>

          <button class="partners-arrow" data-dir="next" aria-label="הלוגו הבא">
            <svg width="58" height="12" viewBox="0 0 58 12" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><path d="M0.75 6.27295C0.335787 6.27295 7.24234e-08 5.93716 0 5.52295C-7.24234e-08 5.10874 0.335786 4.77295 0.75 4.77295L0.75 5.52295L0.75 6.27295ZM57.2803 4.99261C57.5732 5.2855 57.5732 5.76038 57.2803 6.05327L52.5074 10.8262C52.2145 11.1191 51.7396 11.1191 51.4467 10.8262C51.1538 10.5333 51.1538 10.0585 51.4467 9.76558L55.6893 5.52294L51.4467 1.2803C51.1538 0.987407 51.1538 0.512533 51.4467 0.219639C51.7396 -0.073254 52.2145 -0.073254 52.5074 0.219639L57.2803 4.99261ZM0.75 5.52295L0.75 4.77295L56.75 4.77294L56.75 5.52294L56.75 6.27294L0.75 6.27295L0.75 5.52295Z" fill="currentColor"/></svg>
          </button>
        </div>
      </div>
<?php endif; ?>
    </section>

    <section class="contact" id="contact">
      <div class="contact-card">
        <div class="contact-top">
          <div class="contact-form-col">
            <h2><?php sunrise_content_html( 'contact_heading' ); ?></h2>
            <form id="sunrise-contact-form" novalidate>
              <div class="contact-form-row">
                <div class="contact-field">
                  <label for="c-name">שם</label>
                  <input id="c-name" name="name" type="text" required aria-required="true" autocomplete="name" maxlength="100" aria-describedby="c-status">
                </div>
                <div class="contact-field">
                  <label for="c-phone">טלפון</label>
                  <input id="c-phone" name="phone" type="tel" required aria-required="true" autocomplete="tel" maxlength="30" aria-describedby="c-status">
                </div>
              </div>
              <div class="contact-field">
                <label for="c-email">אימייל</label>
                <input id="c-email" name="email" type="email" required aria-required="true" autocomplete="email" maxlength="254" aria-describedby="c-status">
              </div>
              <div class="contact-field">
                <label for="c-message">הודעה</label>
                <textarea id="c-message" name="message" rows="1" maxlength="5000"></textarea>
              </div>
              <!-- Honeypot — hidden from real visitors via CSS, invisible to
                   screen readers; a filled-in value means it was a bot. -->
              <div class="contact-field contact-field--hp" aria-hidden="true">
                <label for="c-website">אתר</label>
                <input id="c-website" name="website" type="text" tabindex="-1" autocomplete="off">
              </div>
              <button class="pill-btn contact-submit" type="submit">
                <span class="contact-submit-label">שליחה</span>
                <svg width="24" height="10" viewBox="0 0 24 10" fill="none" aria-hidden="true"><path d="M23 5H1M1 5L5.5 1M1 5L5.5 9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
              </button>
              <p class="contact-form-status" id="c-status" role="status" aria-live="polite"></p>
            </form>
          </div>

          <div class="contact-image-col">
            <img class="contact-bg-img" src="<?php echo $img_url; ?>/contact-bg.png" alt="">
            <div class="contact-image-content">
              <div class="contact-logo" role="heading" aria-level="2"><span class="dot"></span>בואו נדבר</div>
              <p><?php sunrise_content_html( 'contact_box_text' ); ?></p>
              <a class="pill-btn contact-cta" href="#c-name">
                <?php sunrise_content_html( 'contact_box_cta' ); ?>
                <svg width="24" height="10" viewBox="0 0 24 10" fill="none" aria-hidden="true"><path d="M23 5H1M1 5L5.5 1M1 5L5.5 9" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
              </a>
            </div>
          </div>
        </div>

        <div class="contact-info-bar">
          <div class="contact-info-item">
            <svg width="14" height="17" viewBox="0 0 14 17" fill="none"><path d="M7 16C7 16 13 10.5 13 6.5C13 3.18629 10.3137 1 7 1C3.68629 1 1 3.18629 1 6.5C1 10.5 7 16 7 16Z" stroke="currentColor" stroke-width="1.2"/><circle cx="7" cy="6.5" r="2" stroke="currentColor" stroke-width="1.2"/></svg>
            <?php sunrise_content_html( 'contact_address' ); ?>
          </div>
          <div class="contact-info-item">
            <svg width="18" height="14" viewBox="0 0 18 14" fill="none"><rect x="1" y="1" width="16" height="12" rx="1.5" stroke="currentColor" stroke-width="1.2"/><path d="M1.5 1.5L9 8L16.5 1.5" stroke="currentColor" stroke-width="1.2"/></svg>
            <span>מייל: <?php sunrise_content_link( 'contact_email', $sunrise_contact['email'] ); ?></span>
          </div>
          <div class="contact-info-item">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M2 3C2 2.44772 2.44772 2 3 2H5.5L6.5 5.5L4.8 6.6C5.4 8.2 6.8 9.6 8.4 10.2L9.5 8.5L13 9.5V12C13 12.5523 12.5523 13 12 13C6.5 13 2 8.5 2 3Z" stroke="currentColor" stroke-width="1.2" stroke-linejoin="round"/></svg>
            <span>טלפון: <?php sunrise_content_link( 'contact_phone', $sunrise_contact['phone'] ); ?></span>
          </div>
          <div class="contact-info-item">
            <svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M2 14L2.9 11.1C2.3 10 2 8.8 2 7.5C2 3.9 4.9 1 8.5 1C12.1 1 15 3.9 15 7.5C15 11.1 12.1 14 8.5 14C7.3 14 6.1 13.7 5.1 13.1L2 14Z" stroke="currentColor" stroke-width="1.2" stroke-linejoin="round"/></svg>
            <span>ווטסאפ: <?php sunrise_content_link( 'contact_whatsapp', $sunrise_contact['whatsapp'] ); ?></span>
          </div>
        </div>
      </div>
    </section>
<?php get_footer(); ?>
