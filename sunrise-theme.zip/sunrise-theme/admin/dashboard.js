(() => {
  const root = document.getElementById('sunrise-dashboard-root');
  const API = sunriseDash.restUrl;
  const SUNRISE_API = sunriseDash.sunriseApiUrl;
  const HEADERS = { 'X-WP-Nonce': sunriseDash.nonce };

  let projects = [];
  let partners = [];
  let activeTab = 'projects';
  let contentValues = null;
  let contentDirty = false;

  const api = async (path, opts = {}, base = API) => {
    const res = await fetch(base + path, {
      ...opts,
      headers: { ...HEADERS, ...(opts.headers || {}) },
    });
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      throw new Error(body.message || 'שגיאה בשרת');
    }
    return res.status === 204 ? null : res.json();
  };

  const escapeHtml = s => (s || '').replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));

  async function loadProjects() {
    projects = await api('projects?per_page=100&orderby=menu_order&order=asc&_embed=wp:featuredmedia&status=publish,draft,pending');
  }

  function thumbUrl(p) {
    const media = p._embedded && p._embedded['wp:featuredmedia'] && p._embedded['wp:featuredmedia'][0];
    if (!media) return null;
    const sizes = media.media_details && media.media_details.sizes;
    return (sizes && sizes.medium && sizes.medium.source_url) || media.source_url;
  }

  // ---- Shell + tabs ----
  function render() {
    root.innerHTML = `
      <div class="sd-topbar">
        <div class="sd-logo">SUNRISE<span class="dot"> ·</span> לוח בקרה</div>
        <div class="sd-topbar-right">
          <a class="sd-logout" href="${sunriseDash.logoutUrl}">התנתקות</a>
        </div>
      </div>
      <div class="sd-tabs">
        <button class="sd-tab${activeTab === 'projects' ? ' sd-tab--active' : ''}" data-tab="projects">ניהול פרויקטים</button>
        <button class="sd-tab${activeTab === 'content' ? ' sd-tab--active' : ''}" data-tab="content">תוכן האתר</button>
        <button class="sd-tab${activeTab === 'partners' ? ' sd-tab--active' : ''}" data-tab="partners">לוגואים — שיתופי פעולה</button>
      </div>
      <div class="sd-main" id="sd-view"></div>
    `;
    root.querySelectorAll('.sd-tab').forEach(btn => {
      btn.addEventListener('click', () => {
        if (btn.dataset.tab === activeTab) return;
        if (activeTab === 'content' && contentDirty && !confirm('יש שינויים שלא נשמרו בתוכן האתר. לעבור בכל זאת?')) return;
        activeTab = btn.dataset.tab;
        render();
      });
    });
    if (activeTab === 'projects') renderProjectsView();
    else if (activeTab === 'partners') renderPartnersView();
    else renderContentView();
  }

  // ---- Projects tab ----
  function renderProjectsView() {
    const view = document.getElementById('sd-view');
    view.innerHTML = `
      <div class="sd-main-header">
        <div>
          <h1>הפרויקטים שלי</h1>
          <p>כל שינוי כאן מתעדכן מיד באתר, בסדר שבו הכרטיסים מופיעים כאן.</p>
        </div>
        <button class="sd-btn sd-btn-primary" id="sd-add-btn">+ הוספת פרויקט</button>
      </div>
      <div id="sd-grid"></div>
    `;
    document.getElementById('sd-add-btn').addEventListener('click', () => openModal(null));
    renderGrid();
  }

  function renderGrid() {
    const grid = document.getElementById('sd-grid');
    if (!grid) return;
    if (!projects.length) {
      grid.innerHTML = '<div class="sd-empty">עוד אין פרויקטים — לחצו על "הוספת פרויקט" כדי להתחיל.</div>';
      return;
    }
    grid.className = 'sd-grid';
    grid.innerHTML = projects.map((p, i) => {
      const thumb = thumbUrl(p);
      const num = String(i + 1).padStart(2, '0');
      return `
        <div class="sd-card" data-id="${p.id}">
          ${thumb
            ? `<img class="sd-card-image" src="${thumb}" alt="">`
            : `<div class="sd-card-image sd-card-image--empty">אין תמונה</div>`}
          <div class="sd-card-body">
            <span class="sd-card-num">${num}</span>
            <div class="sd-card-title">${escapeHtml(p.title.rendered)}</div>
            <div class="sd-card-desc">${escapeHtml(stripHtml(p.excerpt.rendered))}</div>
            <div class="sd-card-actions">
              <div class="sd-icon-group">
                <button class="sd-icon-btn" data-action="up" ${i === 0 ? 'disabled' : ''} title="הזזה למעלה">↑</button>
                <button class="sd-icon-btn" data-action="down" ${i === projects.length - 1 ? 'disabled' : ''} title="הזזה למטה">↓</button>
              </div>
              <div class="sd-icon-group">
                <button class="sd-icon-btn" data-action="edit" title="עריכה">✎</button>
                <button class="sd-icon-btn" data-action="delete" title="מחיקה">🗑</button>
              </div>
            </div>
          </div>
        </div>
      `;
    }).join('');

    grid.querySelectorAll('.sd-card').forEach(card => {
      const id = Number(card.dataset.id);
      card.querySelector('[data-action="edit"]').addEventListener('click', () => {
        openModal(projects.find(p => p.id === id));
      });
      card.querySelector('[data-action="delete"]').addEventListener('click', () => onDelete(id));
      const upBtn = card.querySelector('[data-action="up"]');
      const downBtn = card.querySelector('[data-action="down"]');
      if (upBtn) upBtn.addEventListener('click', () => onMove(id, -1));
      if (downBtn) downBtn.addEventListener('click', () => onMove(id, 1));
    });
  }

  function stripHtml(html) {
    const d = document.createElement('div');
    d.innerHTML = html;
    return d.textContent || '';
  }

  async function onMove(id, dir) {
    const idx = projects.findIndex(p => p.id === id);
    const swapIdx = idx + dir;
    if (swapIdx < 0 || swapIdx >= projects.length) return;
    const a = projects[idx], b = projects[swapIdx];
    [projects[idx], projects[swapIdx]] = [projects[swapIdx], projects[idx]];
    renderGrid();
    try {
      await Promise.all([
        api(`projects/${a.id}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ menu_order: swapIdx }) }),
        api(`projects/${b.id}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ menu_order: idx }) }),
      ]);
    } catch (e) {
      alert('לא הצלחנו לשמור את הסדר החדש: ' + e.message);
      await refresh();
    }
  }

  async function onDelete(id) {
    if (!confirm('למחוק את הפרויקט הזה? אפשר לשחזר מהאשפה בעמוד הפרויקטים הרגיל אם טעית.')) return;
    try {
      await api(`projects/${id}`, { method: 'DELETE' });
      await refresh();
    } catch (e) {
      alert('מחיקה נכשלה: ' + e.message);
    }
  }

  async function refresh() {
    await loadProjects();
    renderGrid();
  }

  // ---- Add / edit modal ----
  function openModal(project) {
    const isEdit = !!project;
    const overlay = document.createElement('div');
    overlay.className = 'sd-modal-overlay';
    overlay.innerHTML = `
      <div class="sd-modal">
        <h2>${isEdit ? 'עריכת פרויקט' : 'פרויקט חדש'}</h2>
        <div class="sd-field">
          <label>תמונה</label>
          <label class="sd-image-drop" id="sd-image-drop">
            <span id="sd-image-placeholder">${isEdit && thumbUrl(project) ? '' : 'לחצו כדי לבחור תמונה'}</span>
            ${isEdit && thumbUrl(project) ? `<img id="sd-image-preview" src="${thumbUrl(project)}">` : '<img id="sd-image-preview" style="display:none">'}
            <input type="file" id="sd-image-input" accept="image/*">
          </label>
        </div>
        <div class="sd-field">
          <label for="sd-title">כותרת</label>
          <input type="text" id="sd-title" value="${escapeHtml(isEdit ? project.title.rendered : '')}">
        </div>
        <div class="sd-field">
          <label for="sd-desc">תיאור קצר</label>
          <textarea id="sd-desc">${escapeHtml(isEdit ? stripHtml(project.excerpt.rendered) : '')}</textarea>
        </div>
        <div class="sd-modal-error" id="sd-modal-error"></div>
        <div class="sd-modal-actions">
          <button class="sd-btn" id="sd-cancel">ביטול</button>
          <button class="sd-btn sd-btn-primary" id="sd-save">שמירה</button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);

    let newImageFile = null;
    const imageInput = overlay.querySelector('#sd-image-input');
    const preview = overlay.querySelector('#sd-image-preview');
    const placeholder = overlay.querySelector('#sd-image-placeholder');
    imageInput.addEventListener('change', () => {
      const file = imageInput.files[0];
      if (!file) return;
      newImageFile = file;
      preview.src = URL.createObjectURL(file);
      preview.style.display = 'block';
      placeholder.style.display = 'none';
    });

    overlay.querySelector('#sd-cancel').addEventListener('click', () => overlay.remove());
    overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });

    overlay.querySelector('#sd-save').addEventListener('click', async () => {
      const title = overlay.querySelector('#sd-title').value.trim();
      const desc = overlay.querySelector('#sd-desc').value.trim();
      const errorEl = overlay.querySelector('#sd-modal-error');
      const saveBtn = overlay.querySelector('#sd-save');
      if (!title) {
        errorEl.textContent = 'נא להזין כותרת.';
        return;
      }
      saveBtn.disabled = true;
      saveBtn.textContent = 'שומר...';
      errorEl.textContent = '';
      try {
        let mediaId = null;
        if (newImageFile) {
          const fd = new FormData();
          fd.append('file', newImageFile);
          const media = await api('media', { method: 'POST', body: fd });
          mediaId = media.id;
        }
        const payload = { title, excerpt: desc, status: 'publish' };
        if (mediaId) payload.featured_media = mediaId;

        if (isEdit) {
          await api(`projects/${project.id}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
          });
        } else {
          payload.menu_order = projects.length;
          await api('projects', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
          });
        }
        overlay.remove();
        await refresh();
      } catch (e) {
        errorEl.textContent = 'שמירה נכשלה: ' + e.message;
        saveBtn.disabled = false;
        saveBtn.textContent = 'שמירה';
      }
    });
  }

  // ---- Content tab ----
  async function loadContent() {
    contentValues = await api('content', {}, SUNRISE_API);
  }

  function renderContentView() {
    const view = document.getElementById('sd-view');
    const schema = sunriseDash.contentSchema;
    view.innerHTML = `
      <div class="sd-main-header">
        <div>
          <h1>תוכן האתר</h1>
          <p>עריכת הטקסטים שמופיעים בכל אזור באתר. השינויים עולים לאתר מיד עם השמירה.</p>
        </div>
        <button class="sd-btn sd-btn-primary" id="sd-content-save">שמירת כל השינויים</button>
      </div>
      <div class="sd-content-status" id="sd-content-status"></div>
      <div id="sd-content-groups"></div>
    `;
    const groups = document.getElementById('sd-content-groups');
    groups.innerHTML = Object.entries(schema).map(([groupKey, group]) => `
      <div class="sd-content-group">
        <h2>${escapeHtml(group.label)}</h2>
        <div class="sd-content-fields">
          ${Object.entries(group.fields).map(([key, field]) => `
            <div class="sd-field">
              <label for="sd-cf-${key}">${escapeHtml(field.label)}</label>
              ${field.type === 'textarea'
                ? `<textarea id="sd-cf-${key}" data-key="${key}">${escapeHtml(contentValues[key] ?? field.default)}</textarea>`
                : `<input type="text" id="sd-cf-${key}" data-key="${key}" value="${escapeHtml(contentValues[key] ?? field.default)}">`}
            </div>
          `).join('')}
        </div>
      </div>
    `).join('');

    groups.querySelectorAll('[data-key]').forEach(el => {
      el.addEventListener('input', () => { contentDirty = true; });
    });

    document.getElementById('sd-content-save').addEventListener('click', saveContent);
  }

  async function saveContent() {
    const statusEl = document.getElementById('sd-content-status');
    const saveBtn = document.getElementById('sd-content-save');
    const payload = {};
    document.querySelectorAll('#sd-content-groups [data-key]').forEach(el => {
      payload[el.dataset.key] = el.value;
    });
    saveBtn.disabled = true;
    saveBtn.textContent = 'שומר...';
    statusEl.textContent = '';
    statusEl.removeAttribute('data-state');
    try {
      await api('content', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
      }, SUNRISE_API);
      contentValues = payload;
      contentDirty = false;
      statusEl.textContent = 'נשמר בהצלחה.';
      statusEl.setAttribute('data-state', 'ok');
    } catch (e) {
      statusEl.textContent = 'שמירה נכשלה: ' + e.message;
      statusEl.setAttribute('data-state', 'error');
    } finally {
      saveBtn.disabled = false;
      saveBtn.textContent = 'שמירת כל השינויים';
    }
  }


  // ---- Partner logos tab ----
  async function loadPartners() {
    partners = await api('partners?per_page=100&orderby=menu_order&order=asc&_embed=wp:featuredmedia&status=publish');
  }

  function logoUrl(p) {
    const media = p._embedded && p._embedded['wp:featuredmedia'] && p._embedded['wp:featuredmedia'][0];
    if (!media) return null;
    const sizes = media.media_details && media.media_details.sizes;
    return (sizes && sizes.medium && sizes.medium.source_url) || media.source_url;
  }

  // missing meta = on, same default the front end uses
  const isWhite = p => !p.meta || p.meta.sunrise_logo_white !== false;

  function renderPartnersView() {
    const view = document.getElementById('sd-view');
    view.innerHTML = `
      <div class="sd-main-header">
        <div>
          <h1>לוגואים — שיתופי פעולה</h1>
          <p>הלוגואים שרצים ברצועה השחורה באתר, בסדר שבו הם מופיעים כאן. שינוי מתעדכן באתר מיד.</p>
        </div>
        <button class="sd-btn sd-btn-primary" id="sd-add-partner">+ הוספת לוגו</button>
      </div>
      <div id="sd-partner-grid"></div>
    `;
    document.getElementById('sd-add-partner').addEventListener('click', () => openPartnerModal(null));
    renderPartnerGrid();
  }

  function renderPartnerGrid() {
    const grid = document.getElementById('sd-partner-grid');
    if (!grid) return;
    if (!partners.length) {
      grid.className = '';
      grid.innerHTML = '<div class="sd-empty">עוד אין לוגואים — לחצו על "הוספת לוגו". כל עוד אין לוגו, הרצועה לא מוצגת באתר.</div>';
      return;
    }
    grid.className = 'sd-grid sd-grid--logos';
    grid.innerHTML = partners.map((p, i) => {
      const url = logoUrl(p);
      return `
        <div class="sd-card sd-logo-card" data-id="${p.id}">
          <div class="sd-logo-stage">
            ${url ? `<img src="${url}" alt="" class="${isWhite(p) ? 'is-white' : ''}">` : '<span>אין תמונה</span>'}
          </div>
          <div class="sd-card-body">
            <div class="sd-card-title">${escapeHtml(p.title.rendered)}</div>
            <div class="sd-card-actions">
              <div class="sd-icon-group">
                <button class="sd-icon-btn" data-action="up" ${i === 0 ? 'disabled' : ''} title="הזזה אחורה">↑</button>
                <button class="sd-icon-btn" data-action="down" ${i === partners.length - 1 ? 'disabled' : ''} title="הזזה קדימה">↓</button>
              </div>
              <div class="sd-icon-group">
                <button class="sd-icon-btn" data-action="edit" title="עריכה">✎</button>
                <button class="sd-icon-btn" data-action="delete" title="מחיקה">🗑</button>
              </div>
            </div>
          </div>
        </div>
      `;
    }).join('');

    grid.querySelectorAll('.sd-card').forEach(card => {
      const id = Number(card.dataset.id);
      card.querySelector('[data-action="edit"]').addEventListener('click', () => openPartnerModal(partners.find(p => p.id === id)));
      card.querySelector('[data-action="delete"]').addEventListener('click', () => onPartnerDelete(id));
      card.querySelector('[data-action="up"]').addEventListener('click', () => onPartnerMove(id, -1));
      card.querySelector('[data-action="down"]').addEventListener('click', () => onPartnerMove(id, 1));
    });
  }

  async function onPartnerMove(id, dir) {
    const idx = partners.findIndex(p => p.id === id);
    const swapIdx = idx + dir;
    if (swapIdx < 0 || swapIdx >= partners.length) return;
    const a = partners[idx], b = partners[swapIdx];
    [partners[idx], partners[swapIdx]] = [partners[swapIdx], partners[idx]];
    renderPartnerGrid();
    try {
      await Promise.all([
        api(`partners/${a.id}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ menu_order: swapIdx }) }),
        api(`partners/${b.id}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ menu_order: idx }) }),
      ]);
    } catch (e) {
      alert('לא הצלחנו לשמור את הסדר החדש: ' + e.message);
      await refreshPartners();
    }
  }

  async function onPartnerDelete(id) {
    if (!confirm('למחוק את הלוגו הזה? הוא יוסר מהאתר, והקובץ יימחק לגמרי.')) return;
    try {
      await api(`partners/${id}?force=true`, { method: 'DELETE' });
      await refreshPartners();
    } catch (e) {
      alert('מחיקה נכשלה: ' + e.message);
    }
  }

  async function refreshPartners() {
    await loadPartners();
    renderPartnerGrid();
  }

  function openPartnerModal(partner) {
    const isEdit = !!partner;
    const overlay = document.createElement('div');
    overlay.className = 'sd-modal-overlay';
    const curUrl = isEdit ? logoUrl(partner) : null;
    overlay.innerHTML = `
      <div class="sd-modal">
        <h2>${isEdit ? 'עריכת לוגו' : 'לוגו חדש'}</h2>
        <div class="sd-field">
          <label>קובץ הלוגו</label>
          <label class="sd-image-drop sd-image-drop--dark" id="sd-image-drop">
            <span id="sd-image-placeholder">${curUrl ? '' : 'לחצו כדי לבחור קובץ'}</span>
            <img id="sd-image-preview" ${curUrl ? `src="${curUrl}"` : 'style="display:none"'} class="${!isEdit || isWhite(partner) ? 'is-white' : ''}">
            <input type="file" id="sd-image-input" accept="image/png,image/webp,image/jpeg">
          </label>
          <small class="sd-hint">הכי טוב: קובץ PNG עם רקע שקוף. הרצועה באתר כהה — לוגו עם רקע לבן מלא (JPG) ייראה כמלבן לבן.</small>
        </div>
        <div class="sd-field">
          <label for="sd-partner-name">שם החברה (מופיע כטקסט חלופי לתמונה)</label>
          <input type="text" id="sd-partner-name" value="${escapeHtml(isEdit ? partner.title.rendered : '')}">
        </div>
        <div class="sd-field">
          <label class="sd-check"><input type="checkbox" id="sd-partner-white" ${!isEdit || isWhite(partner) ? 'checked' : ''}> להציג כלוגו לבן (מומלץ ללוגו צבעוני או כהה על רקע שקוף)</label>
        </div>
        <div class="sd-modal-error" id="sd-modal-error"></div>
        <div class="sd-modal-actions">
          <button class="sd-btn" id="sd-cancel">ביטול</button>
          <button class="sd-btn sd-btn-primary" id="sd-save">שמירה</button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);

    let newFile = null;
    const input = overlay.querySelector('#sd-image-input');
    const preview = overlay.querySelector('#sd-image-preview');
    const placeholder = overlay.querySelector('#sd-image-placeholder');
    const whiteBox = overlay.querySelector('#sd-partner-white');
    input.addEventListener('change', () => {
      const file = input.files[0];
      if (!file) return;
      newFile = file;
      preview.src = URL.createObjectURL(file);
      preview.style.display = 'block';
      placeholder.style.display = 'none';
    });
    // the preview sits on the same dark stage the site uses, and follows the checkbox
    whiteBox.addEventListener('change', () => preview.classList.toggle('is-white', whiteBox.checked));

    overlay.querySelector('#sd-cancel').addEventListener('click', () => overlay.remove());
    overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });

    overlay.querySelector('#sd-save').addEventListener('click', async () => {
      const name = overlay.querySelector('#sd-partner-name').value.trim();
      const errorEl = overlay.querySelector('#sd-modal-error');
      const saveBtn = overlay.querySelector('#sd-save');
      if (!isEdit && !newFile) { errorEl.textContent = 'נא לבחור קובץ לוגו.'; return; }
      if (!name) { errorEl.textContent = 'נא להזין שם חברה.'; return; }
      saveBtn.disabled = true;
      saveBtn.textContent = 'שומר...';
      errorEl.textContent = '';
      try {
        let mediaId = null;
        if (newFile) {
          const fd = new FormData();
          fd.append('file', newFile);
          const media = await api('media', { method: 'POST', body: fd });
          mediaId = media.id;
        }
        const payload = { title: name, status: 'publish', meta: { sunrise_logo_white: whiteBox.checked } };
        if (mediaId) payload.featured_media = mediaId;
        if (isEdit) {
          await api(`partners/${partner.id}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
        } else {
          payload.menu_order = partners.length;
          await api('partners', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload) });
        }
        overlay.remove();
        await refreshPartners();
      } catch (e) {
        errorEl.textContent = 'שמירה נכשלה: ' + e.message;
        saveBtn.disabled = false;
        saveBtn.textContent = 'שמירה';
      }
    });
  }

  (async function init() {
    try {
      await Promise.all([loadProjects(), loadContent(), loadPartners()]);
      render();
    } catch (e) {
      root.innerHTML = `<div class="sd-spinner">שגיאה בטעינה: ${escapeHtml(e.message)}</div>`;
    }
  })();
})();
