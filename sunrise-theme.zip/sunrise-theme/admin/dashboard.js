(() => {
  const root = document.getElementById('sunrise-dashboard-root');
  const API = sunriseDash.restUrl;
  const HEADERS = { 'X-WP-Nonce': sunriseDash.nonce };

  let projects = [];

  const api = async (path, opts = {}) => {
    const res = await fetch(API + path, {
      ...opts,
      headers: { ...HEADERS, ...(opts.headers || {}) },
    });
    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      throw new Error(body.message || 'שגיאה בשרת');
    }
    return res.status === 204 ? null : res.json();
  };

  const escapeHtml = s => (s || '').replace(/[&<>"']/g, c => ({
    '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
  }[c]));

  async function loadProjects() {
    projects = await api('projects?per_page=100&orderby=menu_order&order=asc&_embed=wp:featuredmedia&status=publish,draft,pending');
  }

  function thumbUrl(p) {
    const media = p._embedded && p._embedded['wp:featuredmedia'] && p._embedded['wp:featuredmedia'][0];
    if (!media) return null;
    const sizes = media.media_details && media.media_details.sizes;
    return (sizes && sizes.medium && sizes.medium.source_url) || media.source_url;
  }

  function render() {
    const header = `
      <div class="sd-topbar">
        <div class="sd-logo">SUNRISE<span class="dot"> ·</span> ניהול פרויקטים</div>
        <div class="sd-topbar-right">
          <a class="sd-logout" href="${sunriseDash.logoutUrl}">התנתקות</a>
        </div>
      </div>
      <div class="sd-main">
        <div class="sd-main-header">
          <div>
            <h1>הפרויקטים שלי</h1>
            <p>כל שינוי כאן מתעדכן מיד באתר, בסדר שבו הכרטיסים מופיעים כאן.</p>
          </div>
          <button class="sd-btn sd-btn-primary" id="sd-add-btn">+ הוספת פרויקט</button>
        </div>
        <div id="sd-grid"></div>
      </div>
    `;
    root.innerHTML = header;
    document.getElementById('sd-add-btn').addEventListener('click', () => openModal(null));
    renderGrid();
  }

  function renderGrid() {
    const grid = document.getElementById('sd-grid');
    if (!projects.length) {
      grid.innerHTML = '<div class="sd-empty">עוד אין פרויקטים — לחצו על "הוספת פרויקט" כדי להתחיל.</div>';
      return;
    }
    grid.className = 'sd-grid';
    grid.innerHTML = projects.map((p, i) => {
      const thumb = thumbUrl(p);
      const num = String(i + 1).padStart(2, '0');
      return `
        <div class="sd-card" data-id="${p.id}">
          ${thumb
            ? `<img class="sd-card-image" src="${thumb}" alt="">`
            : `<div class="sd-card-image sd-card-image--empty">אין תמונה</div>`}
          <div class="sd-card-body">
            <span class="sd-card-num">${num}</span>
            <div class="sd-card-title">${escapeHtml(p.title.rendered)}</div>
            <div class="sd-card-desc">${escapeHtml(stripHtml(p.excerpt.rendered))}</div>
            <div class="sd-card-actions">
              <div class="sd-icon-group">
                <button class="sd-icon-btn" data-action="up" ${i === 0 ? 'disabled' : ''} title="הזזה למעלה">↑</button>
                <button class="sd-icon-btn" data-action="down" ${i === projects.length - 1 ? 'disabled' : ''} title="הזזה למטה">↓</button>
              </div>
              <div class="sd-icon-group">
                <button class="sd-icon-btn" data-action="edit" title="עריכה">✎</button>
                <button class="sd-icon-btn" data-action="delete" title="מחיקה">🗑</button>
              </div>
            </div>
          </div>
        </div>
      `;
    }).join('');

    grid.querySelectorAll('.sd-card').forEach(card => {
      const id = Number(card.dataset.id);
      card.querySelector('[data-action="edit"]').addEventListener('click', () => {
        openModal(projects.find(p => p.id === id));
      });
      card.querySelector('[data-action="delete"]').addEventListener('click', () => onDelete(id));
      const upBtn = card.querySelector('[data-action="up"]');
      const downBtn = card.querySelector('[data-action="down"]');
      if (upBtn) upBtn.addEventListener('click', () => onMove(id, -1));
      if (downBtn) downBtn.addEventListener('click', () => onMove(id, 1));
    });
  }

  function stripHtml(html) {
    const d = document.createElement('div');
    d.innerHTML = html;
    return d.textContent || '';
  }

  async function onMove(id, dir) {
    const idx = projects.findIndex(p => p.id === id);
    const swapIdx = idx + dir;
    if (swapIdx < 0 || swapIdx >= projects.length) return;
    const a = projects[idx], b = projects[swapIdx];
    [projects[idx], projects[swapIdx]] = [projects[swapIdx], projects[idx]];
    renderGrid();
    try {
      await Promise.all([
        api(`projects/${a.id}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ menu_order: swapIdx }) }),
        api(`projects/${b.id}`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ menu_order: idx }) }),
      ]);
    } catch (e) {
      alert('לא הצלחנו לשמור את הסדר החדש: ' + e.message);
      await refresh();
    }
  }

  async function onDelete(id) {
    if (!confirm('למחוק את הפרויקט הזה? אפשר לשחזר מהאשפה בעמוד הפרויקטים הרגיל אם טעית.')) return;
    try {
      await api(`projects/${id}`, { method: 'DELETE' });
      await refresh();
    } catch (e) {
      alert('מחיקה נכשלה: ' + e.message);
    }
  }

  async function refresh() {
    await loadProjects();
    renderGrid();
  }

  // ---- Add / edit modal ----
  function openModal(project) {
    const isEdit = !!project;
    const overlay = document.createElement('div');
    overlay.className = 'sd-modal-overlay';
    overlay.innerHTML = `
      <div class="sd-modal">
        <h2>${isEdit ? 'עריכת פרויקט' : 'פרויקט חדש'}</h2>
        <div class="sd-field">
          <label>תמונה</label>
          <label class="sd-image-drop" id="sd-image-drop">
            <span id="sd-image-placeholder">${isEdit && thumbUrl(project) ? '' : 'לחצו כדי לבחור תמונה'}</span>
            ${isEdit && thumbUrl(project) ? `<img id="sd-image-preview" src="${thumbUrl(project)}">` : '<img id="sd-image-preview" style="display:none">'}
            <input type="file" id="sd-image-input" accept="image/*">
          </label>
        </div>
        <div class="sd-field">
          <label for="sd-title">כותרת</label>
          <input type="text" id="sd-title" value="${escapeHtml(isEdit ? project.title.rendered : '')}">
        </div>
        <div class="sd-field">
          <label for="sd-desc">תיאור קצר</label>
          <textarea id="sd-desc">${escapeHtml(isEdit ? stripHtml(project.excerpt.rendered) : '')}</textarea>
        </div>
        <div class="sd-modal-error" id="sd-modal-error"></div>
        <div class="sd-modal-actions">
          <button class="sd-btn" id="sd-cancel">ביטול</button>
          <button class="sd-btn sd-btn-primary" id="sd-save">שמירה</button>
        </div>
      </div>
    `;
    document.body.appendChild(overlay);

    let newImageFile = null;
    const imageInput = overlay.querySelector('#sd-image-input');
    const preview = overlay.querySelector('#sd-image-preview');
    const placeholder = overlay.querySelector('#sd-image-placeholder');
    imageInput.addEventListener('change', () => {
      const file = imageInput.files[0];
      if (!file) return;
      newImageFile = file;
      preview.src = URL.createObjectURL(file);
      preview.style.display = 'block';
      placeholder.style.display = 'none';
    });

    overlay.querySelector('#sd-cancel').addEventListener('click', () => overlay.remove());
    overlay.addEventListener('click', e => { if (e.target === overlay) overlay.remove(); });

    overlay.querySelector('#sd-save').addEventListener('click', async () => {
      const title = overlay.querySelector('#sd-title').value.trim();
      const desc = overlay.querySelector('#sd-desc').value.trim();
      const errorEl = overlay.querySelector('#sd-modal-error');
      const saveBtn = overlay.querySelector('#sd-save');
      if (!title) {
        errorEl.textContent = 'נא להזין כותרת.';
        return;
      }
      saveBtn.disabled = true;
      saveBtn.textContent = 'שומר...';
      errorEl.textContent = '';
      try {
        let mediaId = null;
        if (newImageFile) {
          const fd = new FormData();
          fd.append('file', newImageFile);
          const media = await api('media', { method: 'POST', body: fd });
          mediaId = media.id;
        }
        const payload = { title, excerpt: desc, status: 'publish' };
        if (mediaId) payload.featured_media = mediaId;

        if (isEdit) {
          await api(`projects/${project.id}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
          });
        } else {
          payload.menu_order = projects.length;
          await api('projects', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
          });
        }
        overlay.remove();
        await refresh();
      } catch (e) {
        errorEl.textContent = 'שמירה נכשלה: ' + e.message;
        saveBtn.disabled = false;
        saveBtn.textContent = 'שמירה';
      }
    });
  }

  (async function init() {
    try {
      await loadProjects();
      render();
    } catch (e) {
      root.innerHTML = `<div class="sd-spinner">שגיאה בטעינה: ${escapeHtml(e.message)}</div>`;
    }
  })();
})();
