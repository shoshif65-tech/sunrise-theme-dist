  </div>

  <footer class="site-footer">
    <div class="site-footer-row">
      <div class="logo"><a href="<?php echo esc_url( home_url( '/' ) ); ?>" style="display:block"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/logo-sunrise.png" alt="Sunrise"></a></div>
      <ul class="footer-nav">
        <?php // Full URLs (not bare #anchors) so the menu also works from inner pages like "all projects". ?>
        <li><a href="<?php echo esc_url( home_url( '/#hero' ) ); ?>">דף הבית</a></li>
        <li>|</li>
        <li><a href="<?php echo esc_url( home_url( '/#about' ) ); ?>">אודות</a></li>
        <li>|</li>
        <li><a href="<?php echo esc_url( home_url( '/#projects' ) ); ?>">פרויקטים</a></li>
        <li>|</li>
        <li><a href="<?php echo esc_url( home_url( '/#partners' ) ); ?>">שת״פ</a></li>
        <li>|</li>
        <li><a href="<?php echo esc_url( home_url( '/#contact' ) ); ?>">צור קשר</a></li>
      </ul>
      <div class="footer-copyright">©כל הזכויות שמורות לסנרייז</div>
    </div>
    <div class="footer-credit">אפיון עיצוב ופיתוח: שושי פלדמן</div>
  </footer>

<?php wp_footer(); ?>
</body>
</html>
