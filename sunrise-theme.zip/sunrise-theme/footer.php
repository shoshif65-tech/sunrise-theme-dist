  </div>

  <footer class="site-footer">
    <div class="site-footer-row">
      <div class="logo"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/images/logo-sunrise.png" alt="Sunrise"></div>
      <ul class="footer-nav">
        <li><a href="#hero">דף הבית</a></li>
        <li>|</li>
        <li><a href="#about">אודות</a></li>
        <li>|</li>
        <li><a href="#projects">פרויקטים</a></li>
        <li>|</li>
        <li><a href="#partners">שת״פ</a></li>
        <li>|</li>
        <li><a href="#contact">צור קשר</a></li>
      </ul>
      <div class="footer-copyright">©כל הזכויות שמורות לסנרייז</div>
    </div>
    <div class="footer-credit">אפיון עיצוב ופיתוח: שושי פלדמן</div>
  </footer>

<?php wp_footer(); ?>
</body>
</html>
