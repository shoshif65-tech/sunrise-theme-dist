<?php
/**
 * Fallback template (required by WordPress for every theme). The real
 * design lives in front-page.php; this only renders for URLs that don't
 * match it — e.g. a single project's own permalink, or a 404.
 */
get_header();
?>
<div style="padding:60px 5%; min-height:40vh;">
<?php if ( have_posts() ) : ?>
	<?php while ( have_posts() ) : the_post(); ?>
		<article <?php post_class(); ?>>
			<h1><?php the_title(); ?></h1>
			<?php if ( has_post_thumbnail() ) : ?>
				<?php the_post_thumbnail( 'large' ); ?>
			<?php endif; ?>
			<div><?php the_content(); ?></div>
		</article>
	<?php endwhile; ?>
<?php else : ?>
	<p>הדף לא נמצא.</p>
<?php endif; ?>
</div>
<?php
get_footer();
