<?php
/**
 * "All projects" grid — linked from the homepage's "כל הפרויקטים" button.
 */
get_header();
$img_url = esc_url( get_template_directory_uri() ) . '/images';
?>
    <section class="projects-archive">
      <div class="projects-archive-header">
        <div class="projects-logo"><span class="dot"></span>פרויקטים</div>
        <h1>כל הפרויקטים</h1>
      </div>

      <div class="projects-archive-grid">
<?php
if ( have_posts() ) :
	$i = 0;
	while ( have_posts() ) :
		the_post();
		$num = str_pad( $i + 1, 2, '0', STR_PAD_LEFT );
?>
        <a class="projects-archive-card" href="<?php the_permalink(); ?>">
          <?php if ( has_post_thumbnail() ) : ?>
            <?php the_post_thumbnail( 'large', [ 'class' => 'projects-archive-card-image', 'alt' => esc_attr( get_the_title() ) ] ); ?>
          <?php endif; ?>
          <span class="num"><?php echo esc_html( $num ); ?></span>
          <div class="title"><?php the_title(); ?></div>
          <div class="desc"><?php echo esc_html( get_the_excerpt() ); ?></div>
        </a>
<?php
		$i++;
	endwhile;
else :
	// No real projects added yet — same placeholder set shown on the
	// homepage, so the two pages stay consistent until real ones exist.
	$placeholders = [
		[ 'img' => 'project-photo-2.jpg', 'num' => '01' ],
		[ 'img' => 'project-photo-1.jpg', 'num' => '02' ],
		[ 'img' => 'project-photo-1.jpg', 'num' => '03' ],
		[ 'img' => 'project-photo-2.jpg', 'num' => '04' ],
		[ 'img' => 'project-photo-1.jpg', 'num' => '05' ],
	];
	foreach ( $placeholders as $p ) :
?>
        <div class="projects-archive-card">
          <img class="projects-archive-card-image" src="<?php echo $img_url . '/' . $p['img']; ?>" alt="">
          <span class="num"><?php echo esc_html( $p['num'] ); ?></span>
          <div class="title">מגדל הירקון</div>
          <div class="desc">מגדל מטורף בעל 40 קומות הוקדם בשנת 20253</div>
        </div>
<?php
	endforeach;
endif; ?>
      </div>
    </section>
<?php get_footer(); ?>
