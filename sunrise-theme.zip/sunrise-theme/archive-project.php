<?php
/**
 * "All projects" grid — linked from the homepage's "כל הפרויקטים" button.
 */
get_header();
?>
    <section class="projects-archive">
      <div class="projects-archive-header">
        <div class="projects-logo"><span class="dot"></span>פרויקטים</div>
        <h1>כל הפרויקטים</h1>
      </div>

      <div class="projects-archive-grid">
<?php
if ( have_posts() ) :
	$i = 0;
	while ( have_posts() ) :
		the_post();
		$num = str_pad( $i + 1, 2, '0', STR_PAD_LEFT );
?>
        <a class="projects-archive-card" href="<?php the_permalink(); ?>">
          <?php if ( has_post_thumbnail() ) : ?>
            <?php the_post_thumbnail( 'large', [ 'class' => 'projects-archive-card-image', 'alt' => esc_attr( get_the_title() ) ] ); ?>
          <?php endif; ?>
          <span class="num"><?php echo esc_html( $num ); ?></span>
          <div class="title"><?php the_title(); ?></div>
          <div class="desc"><?php echo esc_html( get_the_excerpt() ); ?></div>
        </a>
<?php
		$i++;
	endwhile;
else :
?>
        <p class="projects-archive-empty">עוד אין פרויקטים להצגה.</p>
<?php endif; ?>
      </div>
    </section>
<?php get_footer(); ?>
