<?php
/**
 * Editable site copy — every piece of real marketing text on the front
 * page (headings, paragraphs, stats, contact details), grouped by the
 * section it lives in. Design/layout stays fixed; only the words are
 * editable, from the dashboard's "תוכן האתר" tab.
 */

function sunrise_content_schema() {
	return [
		'hero' => [
			'label'  => 'הירו (אזור עליון)',
			'fields' => [
				'hero_title' => [ 'label' => 'כותרת', 'type' => 'text', 'default' => 'יזמות ברמה אחרת' ],
				'hero_text'  => [ 'label' => 'טקסט', 'type' => 'textarea', 'default' => 'סן חן מעניקה מענה ושרות מקצועי בהתאמה אישית לגוון רחב של חברות נדל״ן, ומציעה ליזמים חווית שירות ומקצועיות ע״י צוות מקצועי.' ],
			],
		],
		'about' => [
			'label'  => 'אודות',
			'fields' => [
				'about_heading'      => [ 'label' => 'כותרת (Enter = שורה חדשה)', 'type' => 'textarea', 'default' => "יזמות נדל\"ן עם אחריות,\nניסיון ויחס אישי." ],
				'about_p1'           => [ 'label' => 'פסקה 1', 'type' => 'textarea', 'default' => 'סנרייז היא חברת יזמות ובנייה הפועלת מתוך מחויבות אמיתית לסטנדרטים הגבוהים ביותר, בשילוב ליווי אישי, שקיפות מלאה ותכנון קפדני עד לפרטים הקטנים.' ],
				'about_p2'           => [ 'label' => 'פסקה 2', 'type' => 'textarea', 'default' => 'אנו מאמינים ביצירת ערך ארוך טווח ללקוחות ולמשקיעים, דרך פרויקטים איכותיים במיקומים מבוקשים, עם תכנון מוקפד, עיצוב מוקפד וביצוע ללא פשרות.' ],
				'about_p3'           => [ 'label' => 'פסקה 3', 'type' => 'textarea', 'default' => 'כל פרויקט שלנו נבנה על יסודות של אמון, חדשנות ואחריות – מהרעיון ועד המפתח.' ],
				'about_stat1_value'  => [ 'label' => 'סטטיסטיקה 1 — מספר', 'type' => 'text', 'default' => '100' ],
				'about_stat1_label'  => [ 'label' => 'סטטיסטיקה 1 — תווית', 'type' => 'text', 'default' => 'ליווי אישי' ],
				'about_stat2_value'  => [ 'label' => 'סטטיסטיקה 2 — מספר', 'type' => 'text', 'default' => '40' ],
				'about_stat2_label'  => [ 'label' => 'סטטיסטיקה 2 — תווית', 'type' => 'text', 'default' => 'פרויקטים' ],
				'about_stat3_value'  => [ 'label' => 'סטטיסטיקה 3 — מספר', 'type' => 'text', 'default' => '35' ],
				'about_stat3_label'  => [ 'label' => 'סטטיסטיקה 3 — תווית', 'type' => 'text', 'default' => 'שנות ניסיון' ],
				'about_stat4_value'  => [ 'label' => 'סטטיסטיקה 4 — מספר', 'type' => 'text', 'default' => '1680' ],
				'about_stat4_label'  => [ 'label' => 'סטטיסטיקה 4 — תווית', 'type' => 'text', 'default' => 'שנת הקמה' ],
				'about_person_name'  => [ 'label' => 'שם האיש בתמונה', 'type' => 'text', 'default' => 'ברוך ערבליך' ],
				'about_person_title' => [ 'label' => 'תפקיד (Enter = שורה חדשה)', 'type' => 'textarea', 'default' => "מייסד ומנכ\"ל\nSUNRISE" ],
			],
		],
		'partners' => [
			'label'  => 'שיתופי פעולה',
			'fields' => [
				'partners_badge_number' => [ 'label' => 'מספר בתג', 'type' => 'text', 'default' => '40+' ],
				'partners_badge_text'   => [ 'label' => 'טקסט בתג (Enter = שורה חדשה)', 'type' => 'textarea', 'default' => "אמון של\nהחברות המובילות" ],
				'partners_subtitle'     => [ 'label' => 'כותרת משנה', 'type' => 'text', 'default' => 'חברות ויזמים שבחרו לעבוד איתנו' ],
			],
		],
		'contact' => [
			'label'  => 'יצירת קשר',
			'fields' => [
				'contact_heading'   => [ 'label' => 'כותרת הטופס', 'type' => 'text', 'default' => 'צרו אתנו קשר' ],
				'contact_box_text'  => [ 'label' => 'טקסט בתיבה הכהה (Enter = שורה חדשה)', 'type' => 'textarea', 'default' => "השאירו פרטים ונחזור אליכם בהקדם עם כל המידע\nעל הפרויקט ותהליך הרכישה." ],
				'contact_box_cta'   => [ 'label' => 'כפתור בתיבה הכהה', 'type' => 'text', 'default' => 'לקביעת פגישה ייעוץ' ],
				'contact_address'   => [ 'label' => 'כתובת', 'type' => 'text', 'default' => 'מגדל הכשרת הישוב ב"ב' ],
				'contact_email'     => [ 'label' => 'אימייל', 'type' => 'text', 'default' => 'office@sun0chen.co.il' ],
				'contact_phone'     => [ 'label' => 'טלפון', 'type' => 'text', 'default' => '02-8796678' ],
				'contact_whatsapp'  => [ 'label' => 'ווטסאפ', 'type' => 'text', 'default' => '0548102424' ],
			],
		],
		'general' => [
			'label'  => 'כללי',
			'fields' => [
				'cta_text' => [ 'label' => 'טקסט כפתור "דברו איתנו" (מופיע בכמה מקומות)', 'type' => 'text', 'default' => 'דברו איתנו' ],
			],
		],
	];
}

/** Flat key => default value map, built once from the schema above. */
function sunrise_content_defaults() {
	static $defaults = null;
	if ( $defaults === null ) {
		$defaults = [];
		foreach ( sunrise_content_schema() as $group ) {
			foreach ( $group['fields'] as $key => $field ) {
				$defaults[ $key ] = $field['default'];
			}
		}
	}
	return $defaults;
}

/** Get one piece of site copy — the saved value if set, else its default. */
function sunrise_content( $key ) {
	$stored   = get_option( 'sunrise_content', [] );
	$defaults = sunrise_content_defaults();
	if ( isset( $stored[ $key ] ) && $stored[ $key ] !== '' ) {
		return $stored[ $key ];
	}
	return $defaults[ $key ] ?? '';
}

/** Same text, HTML-escaped with newlines turned into <br> for display. */
function sunrise_content_html( $key ) {
	echo nl2br( esc_html( sunrise_content( $key ) ) );
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'sunrise/v1', '/content', [
		'methods'             => 'GET',
		'permission_callback' => function () {
			return current_user_can( 'manage_sunrise_content' );
		},
		'callback'            => function () {
			$stored = get_option( 'sunrise_content', [] );
			return array_merge( sunrise_content_defaults(), $stored );
		},
	] );
	register_rest_route( 'sunrise/v1', '/content', [
		'methods'             => 'POST',
		'permission_callback' => function () {
			return current_user_can( 'manage_sunrise_content' );
		},
		'callback'            => function ( WP_REST_Request $req ) {
			$defaults = sunrise_content_defaults();
			$incoming = $req->get_json_params();
			if ( ! is_array( $incoming ) ) {
				return new WP_REST_Response( [ 'success' => false, 'message' => 'נתונים לא תקינים.' ], 400 );
			}
			$clean = [];
			foreach ( $defaults as $key => $default ) {
				if ( isset( $incoming[ $key ] ) ) {
					$clean[ $key ] = sanitize_textarea_field( wp_unslash( $incoming[ $key ] ) );
				}
			}
			update_option( 'sunrise_content', $clean );
			return new WP_REST_Response( [ 'success' => true ], 200 );
		},
	] );
} );
