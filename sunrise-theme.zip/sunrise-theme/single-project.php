<?php
/**
 * One project's own page — kept simple on purpose: image, title,
 * description, a CTA back to the contact section. No extra gallery/specs.
 */
get_header();
while ( have_posts() ) :
	the_post();
	$body = get_the_content();
	$body = $body ? apply_filters( 'the_content', $body ) : wpautop( esc_html( get_the_excerpt() ) );
?>
    <section class="project-single">
      <a class="project-single-back" href="<?php echo esc_url( get_post_type_archive_link( 'project' ) ); ?>">
        <svg width="24" height="10" viewBox="0 0 24 10" fill="none"><path d="M23 5H1M1 5L4 2.5M1 5L4 7.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg>
        לכל הפרויקטים
      </a>

      <?php if ( has_post_thumbnail() ) : ?>
        <?php the_post_thumbnail( 'large', [ 'class' => 'project-single-image', 'alt' => esc_attr( get_the_title() ) ] ); ?>
      <?php endif; ?>

      <div class="project-single-body">
        <h1 class="project-single-title"><?php the_title(); ?></h1>
        <div class="project-single-desc"><?php echo $body; ?></div>

        <a class="pill-btn" href="<?php echo esc_url( home_url( '/#contact' ) ); ?>">
          <?php sunrise_content_html( 'cta_text' ); ?>
          <svg width="24" height="10" viewBox="0 0 24 10" fill="none"><path d="M23 5H1M1 5L4 2.5M1 5L4 7.5" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" vector-effect="non-scaling-stroke"/></svg>
        </a>
      </div>
    </section>
<?php
endwhile;
get_footer();
